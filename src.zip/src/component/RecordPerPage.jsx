import React, { useState,useEffect } from "react";
import Notify from "component/Notify";
import POST from "axios/post";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message"


function RecordPerPage({filterItem, perPageItem}) {
    const { apiToken, language,settingGrpKeyInfo} = useSelector((state) => state.login);
  
  // console.log(JSON.parse(settingGrpKeyInfo).option_type);

  const keyinfo = JSON.parse(settingGrpKeyInfo);


  
    const [error, setError] = useState({
      status: false,
      msg: "",
      type: "",
    });
    const [formloadingStatus, SetformloadingStatus] = useState(false);
    const [contentloadingStatus, SetloadingStatus] = useState(false);

    const searchItem = (value) => {
        filterItem("perpage",value,"")
    }
    const [key, setKey] = useState("per_page_item");

    const [sectionListing, SetSectionListing] = useState([]);
    const [itemlist,SetItemlist]=useState(" ");

    let optionValuesAry = '';
    if(keyinfo.setting_options != '' && keyinfo.setting_options != null && keyinfo.option_type == 'dropdown'){
        let optionString = keyinfo.setting_options;
        optionValuesAry = optionString.split(',');
    } else{
        optionValuesAry = '';
    }

    return (
        <label htmlFor="perPage">
            {/* <select
                name="perPage"
                id="perPage"
                className="form-control"
              
                onChange={(e) => searchItem(e.target.value)}
            > */}
      
                     {keyinfo.setting_key === "per_page_item"  && (
                              
                            <React.Fragment>      
                              <select
                                name="perPage"
                                id="perPage"
                              
                                className="form-control"
                              
                                defaultValue={keyinfo.setting_value}
                                onChange={(e) => searchItem(e.target.value)}
                              >
                           { optionValuesAry.length && optionValuesAry.map((label) => <option value={label} >{label}</option>)}
                             
                              </select>
                            </React.Fragment>
                       )  }
               
        </label>
    )
}

export default RecordPerPage
