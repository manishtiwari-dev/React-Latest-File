export const bannerSetting = `/banner-setting`;
export const SliderSetting = `/slider`;

export const WebSetting = `/web-setting`;
export const AppSetting = `/app-settings`;
export const PageSetting = `/pages-setting`;
export const BlogPostSetting = `/blog-setting`;
export const MenuSetting = `/menu-setting`;
export const EmailSetting = `/email-settings`;
export const FeaturedProduct = `/feature-product`;
export const SettingGroup = `/setting-group`;
export const Ticket = `/ticket`;
export const EmailContact = `/email-contact`;
export const TemplateSetting = `/themes`;
export const SuperadminUrl =`superadmin`;



