import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { Anchor } from "component/UIElement/UIElement";

import { Trans } from "lang/index";
import { ListingShowUrl ,ListingChangeStatusUrl} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import FeatherIcon from "feather-icons-react";
import Notify from "component/Notify";
import WebsiteLink from "config/WebsiteLink";

import { Alert, Tab, Tabs } from "react-bootstrap";
export default function Detail() {
  const findOptionName = (dataArray, findid) => {
    const attrname = dataArray.filter((data) => {
      return data.products_options_id === findid
        ? data.products_options_name
        : "";
    });
    return attrname.length > 0 ? attrname[0]["products_options_name"] : "";
  };

  const { proId } = useParams();


  let bod = new Array();
  let stringArray;
  let uniqueArray;
  const findOptionValueName = (dataArray, findid) => {
    let temp = new Array();
    var obj = {};
    dataArray.map((e) => {
      if (e.products_options_id == findid) {
        obj[e.products_options_values_id] = e.products_options_values_name;
      }
    });
    bod.push(obj);
  };


  const { listing_id } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [DataList, SetDataList] = useState();
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);
  const [mainimg, setmainimg] = useState();
 
  const [EditData, setData] = useState();

  let stat;
  useEffect(() => {
    let abortController = new AbortController();
    const getData = () => {
      const editData = {
        api_token: apiToken,
        listing_id: proId,
      };
      POST(ListingShowUrl, editData)
        .then((response) => {
          const { status, data, message } = response.data;
          if (status) {
            SetloadingStatus(false);
            SetDataList(data.data_list);
            SetlangList(data.language);
          } else alert(message);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
    };
    getData();

    return () => {
      // checkactive(DataList?.product_status);
      getData();
      abortController.abort();
    };
  }, [listing_id]);

  
 

  {
    DataList?.status == "active"
      ? (stat = "green")
      : DataList?.status == "deactive"
      ? (stat = "danger")
      : (stat = "warning");
  }
  let optionAry = new Array();
  let valueAry = new Array();



  {
    DataList?.productAttribute &&
      DataList?.productAttribute.map((attr, idx) => {
        {
          const index = optionAry.findIndex(
            (element) =>
              element === findOptionName(attr.option_list, attr.options_id)
          );
          if (index !== -1) {
            //array1.push(findOptionName(attr.option_list, attr.options_id));
          } else {
            let valueName = [];
            optionAry.push(findOptionName(attr.option_list, attr.options_id));
            attr?.option_value_list.map((attrval, idx) => {
              valueName.push(attrval.listing_options_values_name);
            });
            valueAry.push(valueName);
          }
        }
      });
  }

 

  const ChangeFunction = (update_id, statusId) => {
    const editData = {
      api_token: apiToken,
      update_id: update_id,
      statusId: statusId,
    };
    POST(ListingChangeStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
      //   filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const [showType, SetShowType] = useState("");
  const stSarr = ["Draft", "Active", "Inactive"];
  const stSarrC = ["warning", "success", "danger"];
  const StatusChange = (quoteId, statusId) => {
    ChangeFunction(quoteId, statusId);
  };
  const [langList, SetlangList] = useState([]);
  const [key, setKey] = useState("default_language");

  return (
    <Content>
  
   <div className="container-fluid mt-5 mb-5">
          <div className="row g-0">
            {DataList?.listing_image && (
              <div className="col-md-4 border-end">
                <div className="d-flex flex-column justify-content-center">
                  <div className="product_carousel">
                   
                    <img
                      src={mainimg ? mainimg : DataList?.listing_image}
                      id="main_product_image"
                      width="350"
                    />{" "}
                  </div>
                  <div className="thumbnail_images">
                    <ul id="thumbnail">
                      {DataList?.gallery_image.map((material, index = 1) => {
                        return (
                          <>
                            <li>
                              <img
                                onClick={() => setmainimg(material)}
                                src={material}
                                width="70"
                              />
                            </li>
                          </>
                        );
                      })}
                    </ul>
                  </div>
                </div>
                {DataList?.productdescription_with_lang && (
                  <>
                    {DataList?.productdescription_with_lang.map((oldlist) => {
                      return (
                        <div className="card mg-b-20 mg-lg-b-25">
                          <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                            <h6 className=" tx-semibold mg-b-0">
                            {Trans("LISTING_DESCRIPTION", language)}({oldlist.languages_name})</h6>
                          </div>
                         
                          <div className="card-body pd-25">
                         
                            <div className="media d-block d-sm-flex">
                              <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html:
                                      DataList?.productdescription[
                                        oldlist.languages_id - 1
                                      ]?.listing_description,
                                  }}
                                ></div>
                              </div>
                            </div>
                          
                          </div>
                         
                        </div>
                      );
                    })}
                  </>
                )}
              </div>
            )}
            <div className="col-md-8">
              <div className="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">
                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans("LISTING_INFORMATION", language)}
                    </h6>
                    <div className="product_btn">
                    <Anchor
              path={WebsiteLink("/business-listing/create")}
              className="btn btn-primary btn-sm"
            >
              {Trans("ADD_MORE_LISTING", language)}
            </Anchor>
            {"   "} {"  "} &nbsp;
            <Anchor
              path={WebsiteLink(
                `/business-listing/edit/${DataList?.listing_id}`
              )}
              className="btn btn-info btn-sm"
            >
              {Trans("EDIT_LISTING", language)}
            </Anchor>
            {"   "} {"  "} &nbsp;
            <Anchor
              path={WebsiteLink("/business-listing")}
              className="btn btn-warning btn-sm"
            >
              {Trans("GO_BACK", language)}
            </Anchor>
                    </div>
                  
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="d-flex justify-content-between">
                          <div>
                            <h5 className="mb-0">
                              {DataList?.productdescription[0]?.listing_name}
                            </h5>
                          </div>
                          <div>
                     
                              <>
                         <select
                            value={DataList?.status}
                            onChange={(e) => {
                              StatusChange(DataList?.listing_id, e.target.value);
                            }}
                            className={`badge badge-${stSarrC[DataList?.status]}`}
                          >
                            <option value={0}>
                              {Trans("Draft", language)}
                            </option>
                            <option value={1}>
                              {Trans("Active", language)}
                            </option>
                            <option value={2}>
                              {Trans("Inactive", language)}
                            </option>
                          </select>
                               
                              </>
                          
                          </div>
                        </div>
                        <div className="table  table-dashboard">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                {DataList?.productdescription && (
                                  <>
                                    <td> {Trans("LISTING_NAME", language)}</td>
                                    <td>
                                      {
                                        DataList?.productdescription[0]
                                          ?.listing_name
                                      }
                                    </td>
                                  </>
                                )}
                              </tr>
                              {DataList?.selected_category && (
                                <>
                                  {DataList.selected_category.map((list) => {
                                    return (
                                      <tr>
                                        <td>
                                          {" "}
                                          {Trans("Category :", language)}
                                        </td>
                                        <td>{list.label}</td>
                                      </tr>
                                    );
                                  })}
                                </>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                  
                      <h6 className=" tx-semibold mg-b-0">
                        {Trans("LISTING_PRICE", language)}
                        
                      </h6>


                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                   
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellspacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                           <tbody>
                              <tr>
                                <>
                                  {DataList?.product_price.map((lit) => {
                                    return (
                                      <td>{Trans("RATE_TYPE", language)}{" "}:{`${lit.rate_type}`}</td>
                                     
                                    );
                                  })}
                                </>
                              </tr>
                              <tr>
                                <>
                                  {DataList?.product_price.map((lit) => {
                                    return (
                                      <td>{Trans("BASE_RATE", language)}{" "}:{`${lit.base_rate}`}</td>
                                    );
                                  })}
                                </>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans("LISTING_ATTRIBUTE_INFO", language)}
                    </h6>
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              {optionAry && (
                                <>
                                  {optionAry.map((e, ind) => {
                                    const linkContent = valueAry[ind];
                                    console.log(e);
                                    return (
                                      <>
                                        <tr>
                                          <td>{e}</td>
                                          <td>
                                            <ul className="pd-l-10 mg-0 mt-2 tx-13">
                                              {linkContent.map((e) => {
                                                return( <>
                                                <li>{e}
                                                {/* <ul>
                                                <li>{e}</li></ul> */}
                                                </li>
                                                </>);
                                              })}
                                            </ul>
                                          </td>
                                        </tr>

                                       
                                      </>
                                    );
                                  })}
                                  {/* {valueAry.map((student) => {
                                      return <td> {student}</td>;
                                    })} */}

                                </>
                                // </tr>
                              )}

                                   {/* <tr>
                                          <td>{Trans("OPTION_VALUE_PRICE", language)}</td>
                                          <td>
                                            <ul className="pd-l-10 mg-0 mt-2 tx-13">
                                            {DataList?.productAttribute.map((e) => {
                                return (
                                 
                                    <li>  {Trans(e.options_values_price, language)}</li>
                                 
                                );
                              })}





                                            </ul>
                                          </td>
                                        </tr> */}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                    {Trans("LISTING_FEATURE", language)}
                      
                    </h6>
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                <>
                                  {DataList?.product_feature.map((lit) => {
                                    return (
                                      <td>{`${lit.feature_title}  :  ${lit.feature_value}`}</td>
                                    );
                                  })}
                                </>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* <div className="table-responsive mg-t-40">
            <table className="table table-invoice bd-b">
              <thead>
                <tr>
                  <th className="tx-left">{Trans("SL_NO", language)}</th>
              
                  <th className="tx-center">{Trans("QTY", language)}</th>
                  <th className="tx-center">{Trans("INVENTORY_PRICE", language)}</th> 
                  <th className="tx-center">{Trans("PROFIT_PERCENT", language)}</th>
                  <th className="tx-center">{Trans("MAX_SALE_PRICE", language)}</th>
                  <th className="tx-center">{Trans("DISCOUNT", language)}</th>
                  <th className="tx-right">{Trans("FINAL_SALE_PRICE", language)}</th>
                </tr>
              </thead>
              <tbody>
              {DataList?.product_price.map((e,idx) => {
                       
                  return (
                    <tr key={idx}>
                      <td className="tx-left">{idx + 1}</td>
                      <td className="tx-center">  {Trans(e.product_qty, language)}</td>
                      <td>  {Trans(e.stock_price, language)}</td>
                      <td>  {Trans(e.profit_percent, language)}</td>
                      <td>  {Trans(e.max_sale_price, language)}</td>
                       <td>  {Trans(e.discount_percent, language)}</td>
                       <td>  {Trans(e.sale_price, language)}</td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div> */}



              </div>
            </div>
          </div>
      </div>
      </Content>
   

  );
}

