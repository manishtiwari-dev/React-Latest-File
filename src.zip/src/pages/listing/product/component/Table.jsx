import React from "react";
import CheckPermission from "helper";
import FeatherIcon from "feather-icons-react";
import {
  BadgeShow,
  Col,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalAlert from "component/ModalAlert";
import { useState } from "react";
import { PreUpdate, PreRemove, PreView } from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import CategoryTable from "./CategoryTable";
function Table({
  showColumn,
  dataList,
  deleteFun,
  pageName,
  sortBy,
  orderBy,
  filterItem,
  editFun,
  updateStatusFunction,
  UpdateSortOrder,
  mainKey,
  perPage,
  curPage

}) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deleteFun,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  // change Status function
  const ChangeStatus = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: updateStatusFunction,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const editFunction = (editId) => {
    editFun(editId);
  };
  // filter order by id,email etc...
  const searchItem = (value, ord) => {
    filterItem("sortby", value, ord);
  };

  const [showType, SetShowType] = useState("");
  const stSarr = ["Draft", "Active", "Inactive"];
  const stSarrC = ["warning", "success", "danger"];
  const StatusChange = (quoteId, statusId) => {
    updateStatusFunction(quoteId, statusId);
  };

  
  let rowId = (curPage>1)? (curPage-1)* perPage : 0;

  return (
    <>
      <Col col={12}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>{Trans("SL_NO", language)}</th>
                <th>{Trans("LISTING_IMAGE", language)}</th>
                <th>{Trans("LISTING_NAME", language)}</th>
                <th>{Trans("SORT_ORDER")}</th>
                <th>{Trans("STATUS", language)}</th>
                <th>{Trans("ACTION", language)}</th>
              </tr>
            </thead>
            <tbody>
              {dataList.length > 0 &&
                dataList.map((cat, idx) => {
                  const { listing_id, listing_image, listing_name, status,sort_order } =
                    cat;
                    rowId++;
                  return (
                    <React.Fragment key={listing_id}>
                      <tr>
                        <td>{rowId}</td>
                        <td>
                          <img
                            src={listing_image}
                        
                            height="30"
                          />
                        </td>
                        <td>{listing_name}</td>
                        <td>
                        <input
                            type="number"
                            name=""
                            id=""
                            defaultValue={sort_order}
                          

                            style={{ width: "50px" , 'text-align':"center"}}                
                            onBlur={(e) => {
                              UpdateSortOrder(
                                listing_id,
                              e.target.value
                            );
                         }}
                         />
                      
                        </td>

                        <td>
                          <select
                            value={status}
                            onChange={(e) => {
                              StatusChange(listing_id, e.target.value);
                            }}
                            className={`badge badge-${stSarrC[status]}`}
                          >
                            <option value={0}>
                              {Trans("Draft", language)}
                            </option>
                            <option value={1}>
                              {Trans("Active", language)}
                            </option>
                            <option value={2}>
                              {Trans("Inactive", language)}
                            </option>
                          </select>
                        </td>

                        <td>
                          {" "}
                          <Anchor
                            path={WebsiteLink(
                              `/business-listing/show/${listing_id}`
                            )}
                            className="btn btn-primary btn-xs btn-icon"
                          >
                            <FeatherIcon icon="eye" />
                          </Anchor>
                          {"  "}
                          <CheckPermission
                            PageAccess={pageName}
                            PageAction={PreUpdate}
                          >
                            <Anchor
                              path={WebsiteLink(
                                "/business-listing/edit/" + listing_id
                              )}
                              className="btn btn-primary pd-2"
                            >
                              <FeatherIcon icon="edit-2" fill="white" />
                            </Anchor>{" "}
                          </CheckPermission>
                          {"  "}
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Col>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </>
  );
}

export default Table;
