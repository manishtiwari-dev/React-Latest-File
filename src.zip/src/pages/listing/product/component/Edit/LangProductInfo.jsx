import React, { useState } from "react";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import {
  FormGroup,
  Row,
  Col,
  Label,
  Input,
  TextArea,
} from "component/UIElement/UIElement";
import { Tab, Tabs } from "react-bootstrap";
import { useFormContext } from "react-hook-form";
import { ErrorMessage } from "@hookform/error-message";
import ContentEditor from "component/ContentEditor";

function LangProductInfo({ langList ,props,tempEditorValue}) {
  const { language } = useSelector((state) => state.login);
  const [key, setKey] = useState("default_language");
  const methods = useFormContext();
  const {
    register,
    setValue,
    getValues,
    formState: { errors },
  } = methods;

  return (
    <Col col={12}>
      <Tabs
        id="controlled-tab-example"
      
        onSelect={(k) => setKey(k)}
        className="mb-3"
      >
        {langList &&
          langList.map((lang) => {
            const { languages_code, languages_id, languages_name } = lang;

            const test = 
            getValues( `listing_description_${languages_id}` ) === undefined
              ? "<p></p>"
              : getValues(
                  `listing_description_${languages_id}`
                )
           ;

            return (
              <Tab
                eventKey={languages_code}
                key={languages_id}
                title={languages_name}
              >
                
                <Row>
                  <Col col={12}>
                    <FormGroup mb="20px">
                      <Input
                        id={`${Trans(
                          "LISTING_NAME",
                          language
                        )} (${languages_code})`}
                        label={`${Trans(
                          "LISTING_NAME",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "LISTING_NAME",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(`listing_name_${languages_id}`, )}
                      />
                     
                    </FormGroup>
                  </Col>

                  <Col col={12}>
                    <FormGroup mb="20px">
                      <Label>
                        {`${Trans(
                          "LISTING_DESCRIPTION",
                          language
                        )} (${languages_code})`}
                      </Label>


                      <ContentEditor 
                                className="ContentEditor" 
                                initialValue={ tempEditorValue }
                                setKey={`listing_description_${languages_id}`}
                                updateFun={(Key, Value) => {
                                  setValue(Key, Value);
                                }}
                                />
                
                                <textarea
                                  {...register(
                                    `listing_description_${languages_id}`
                                  )}
                                  style={{ display: "none" }}
                                ></textarea>

                      {/* <MyEditor
                        setKey={`listing_description_${languages_id}`}
                        setVal={
                          getValues(`listing_description_${languages_id}`) ===
                          undefined
                            ? "<p></p>"
                            : getValues(`listing_description_${languages_id}`)
                        }
                        updateFun={(Key, Value) => {
                          setValue(Key, Value);
                        }}
                      />
                      <textarea
                        {...register(`listing_description_${languages_id}`, {
                          required: Trans(
                            "LISTING_DESCRIPTION_REQUIRED",
                            language
                          ),
                        })}
                        style={{ display: "none" }}
                      ></textarea> */}
                    
                    </FormGroup>
                  </Col>
                  <Col col={12}>
                    <FormGroup mb="20px">
                      <Input
                        id={`${Trans(
                          "SEO_TITLE",
                          language
                        )} (${languages_code})`}
                        label={`${Trans(
                          "SEO_TITLE",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "SEO_TITLE",
                          language
                        )} (${languages_code})`}
                        hint="Enter text" // for bottom hint
                        className="form-control"
                        {...register(`seometa_title_${languages_id}`)}
                      />
                      <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`seometa_title_${languages_id}`}
                        />
                      </span>
                    </FormGroup>
                  </Col>
                  <Col col={12}>
                    <FormGroup mb="20px">
                      <TextArea
                        id={`${Trans(
                          "SEO_META_DESCRIPTION",
                          language
                        )} (${languages_code})`}
                        label={`${Trans(
                          "SEO_META_DESCRIPTION",
                          language
                        )} (${languages_code})`}
                        placeholder={`${Trans(
                          "SEO_META_DESCRIPTION",
                          language
                        )} (${languages_code})`}
                        className="form-control"
                        {...register(`seometa_desc_${languages_id}`)}
                      />
                      <span className="required">
                        <ErrorMessage
                          errors={errors}
                          name={`seometa_desc_${languages_id}`}
                        />
                      </span>
                    </FormGroup>
                  </Col>
                </Row>
              </Tab>
            );
          })}
      </Tabs>
    </Col>
  );
}

export default LangProductInfo;
