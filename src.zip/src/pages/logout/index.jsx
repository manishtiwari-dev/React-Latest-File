import React, { useState ,useEffect} from "react";
import { useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { logoutState } from "redux/slice/loginSlice";
import WebsiteLink from "config/WebsiteLink";


function Index() {
   const dispatch = useDispatch();
   const navigate = useNavigate();
 

//   /* logout function */
  const logout = () => {
    dispatch(logoutState());
     navigate(WebsiteLink("/login"));
   };


 useEffect(() => {
    
    logout();
 
}, []);

return(
    ''
);

  
}

export default Index;
