import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { AddOnplanPriceStoreUrl, AddOnplanPriceCreateUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  IsFeatured,
  Label,
} from "component/UIElement/UIElement";
import Select from "react-select";

import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import MyEditor from "component/MyEditor";
import { ErrorMessage } from "@hookform/error-message";

const Create = (props) => {
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(false);

  const { register, handleSubmit, setValue , formState: { errors },} = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(AddOnplanPriceStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };



  const [MultiSelectItem, SetMultiSelectItem] = useState("");
  const handleMultiSelectChange = (newValue, actionMeta) => {
    console.log("newValue", newValue);
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    listArr = listArr.join(",");
    console.log("listArr", listArr);
    SetMultiSelectItem(listArr);
    console.log("actionMeta", actionMeta);
  };

  const [planList, SetplanList] = useState([]);

  const getAllData = () => {
    SetloadingStatus(true);
    const filterData2 = {
      api_token: apiToken,
    };
   
    POST(AddOnplanPriceCreateUrl, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
            SetplanList(data.plan_list);
        

        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
      });
  };
  useEffect(() => {
    let abortController = new AbortController();
    getAllData();
    return () => abortController.abort(); //getAllData();
  }, []);


  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <Row>
        {/* <Col col={12}>
                        <FormGroup mb="20px">
                          <Label
                            display="block"
                            mb="5px"
                            htmlFor={Trans("INDUSTRY", language)}
                          >
                            {Trans("INDUSTRY", language)}
                          </Label>
                          <Select
                            isMulti
                            name={Trans("INDUSTRY", language)}
                            options={moduleList}
                            className="basic-multi-select"
                            classNamePrefix="select"
                            onChange={handleMultiSelectChange}
                          />
                        </FormGroup>
                      </Col> */}


            <Col col={12}>
                <FormGroup mb="20px">
                  <Label
                    display="block"
                    mb="5px"
                    htmlFor={Trans("PLAN_NAME", language)}
                  >
                    {Trans("PLAN_NAME", language)}
                  </Label>
                  <select
                    {...register("plan_id", {
                      required: Trans("INDUSTRY_REQUIRED", language),
                    })}
                    className="form-control"
                 
                  >
                    <option>{Trans("SELECT_PLAN_NAME")}</option>
                    {planList &&
                      planList.map((plan, idx) => {
                        return (
                          <option value={plan.plan_id} key={idx}>
                            {plan.plan_name}
                          </option>
                        );
                      })}
                  </select>
                </FormGroup>
              </Col>

     
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("DURATION", language)}
                type="number"
                label={Trans("DURATION", language)}
                placeholder={Trans("DURATION", language)}
                className="form-control"
                {...register("plan_duration", {
                  required: Trans("DURATION_REQUIRED", language),
                })}
              />
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("PLAN_PRICE", language)}
                type="number"
                label={Trans("PLAN_PRICE", language)}
                placeholder={Trans("PLAN_PRICE", language)}
                className="form-control"
                {...register("plan_price", {
                  required: Trans("PLAN_PRICE_REQUIRED", language),
                })}
              />
            </FormGroup>
          </Col>
       

          <Col col={6}>
            <FormGroup mb="20px">
              <Label
                display="block"
                mb="5px"
                htmlFor={Trans("DISCOUNT_TYPE", language)}
              >
                {Trans("DISCOUNT_TYPE", language)}
              </Label>
              <select
                {...register("discount_type")}
                defaultValue={0}
                className="form-control"
              >
                <option value="">{Trans("SELECT_DISCOUNT_TYPE")}</option>
                <option value={0}>{Trans("NO")}</option>
                <option value={1}>{Trans("FIXED")}</option>
                <option value={2}>{Trans("PERCENTAGE")}</option>
              </select>
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("PLAN_DISCOUNT", language)}
                type="number"
                label={Trans("PLAN_DISCOUNT", language)}
                placeholder={Trans("PLAN_DISCOUNT", language)}
                className="form-control"
                {...register("plan_discount")}
              />
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("SET_UP_FEES", language)}
                type="number"
                label={Trans("SET_UP_FEES", language)}
                placeholder={Trans("SET_UP_FEES", language)}
                className="form-control"
                {...register("setup_fee", {
                  required: Trans("SET_UP_FEES_REQUIRED", language),
                })}
              />
            </FormGroup>
          </Col>

          <Col col={6}>
            <FormGroup mb="20px">
              <Label
                display="block"
                mb="5px"
                htmlFor={Trans("SET_UP_DISCOUNT", language)}
              >
                {Trans("SET_UP_DISCOUNT", language)}
              </Label>
              <select
                {...register("setup_fee_discount")}
                defaultValue={0}
                className="form-control"
              >
                <option value="">{Trans("SELECT_SET_UP_DISCOUNT")}</option>
                <option value={0}>{Trans("NO")}</option>
                <option value={1}>{Trans("YES")}</option>
              
              </select>
            </FormGroup>
          </Col>


          
          {/* <Col col={6}>
            <FormGroup mb="20px">
              <StatusSelect
                id={Trans("STATUS", language)}
                label={Trans("STATUS", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("status", {
                  required: Trans("STATUS_REQUIRED", language),
                })}
                defaultValue={1}
              />
            </FormGroup>
          </Col> */}
         

       

          {/* <Col col={12}>
            <FormGroup mb="20px">
            <Input
                type="hidden"
                id={Trans("INDUSTRY", language)}
                label={Trans("INDUSTRY", language)}
                placeholder={Trans("INDUSTRY", language)}
                className="form-control"
                {...register("industry_id", {
                  required: Trans("INDUSTRY_REQUIRED", language),
                })}
              />
              <Select
                isMulti
                name="industry_id"
                options={moduleList}
                className="basic-multi-select"
                classNamePrefix="select"
                onChange={handleMultiSelectChange}
                required
              />
              <span className="required">
                <ErrorMessage errors={errors} name="industry_id" />
              </span>
            </FormGroup>
          </Col> */}

       
          <Col col={4}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("SUBMIT", language)}
              className="btn btn-primary btn-block"
            />
          </Col>
        </Row>
      </form>
    </>
  );
};

export default Create;
