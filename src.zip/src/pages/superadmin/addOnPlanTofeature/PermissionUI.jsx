import React, { useEffect, useState } from "react";
import { planToFeatureUrl ,industryUrlAll} from "config";
import { useSelector } from "react-redux";
import POST from "axios/post";
import Notify from "component/Notify";
import Loading from "component/Loading";
import "assets/css/dashforge.css";
import { Trans } from "lang";
import { useFormContext } from "react-hook-form";
import { LoaderButton, FormGroup, Label } from "component/UIElement/UIElement";

const PermissionUI = (props) => {
  const { register } = useFormContext();
  console.log(props);

  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [permissionList, setPermissionList] = useState([]);
  const [sectionList, SetSectionList] = useState([]);
  const [moduleList, SetModuleList] = useState([]);
  const [contentloadingStatus, SetloadingStatus] = useState(false);
  const [statuslist,SetStatuslist] =useState("yes");
  const [industryList, SetindustryList] = useState([]);
  const [planList, SetplanList] = useState([]);
  const [onSelectLoad, SetonSelectLoad] = useState(false);


  const HandleCheckbox = (e, label) => {
    const listItem = document.querySelectorAll(`.${label}`);
    if (e.target.checked) {
      for (let index = 0; index < listItem.length; index++)
        listItem[index].setAttribute("checked", true);
    } else {
      for (let index = 0; index < listItem.length; index++)
        listItem[index].removeAttribute("checked");
    }
  };

  const [collapseShow, SetcollapseShow] = useState("");
  const handleCollapse = (sectionName) => {
    SetcollapseShow(sectionName);
   
  };

  
  return (
    <React.Fragment>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <React.Fragment>
      
          <div className="row">   
           <div className="col-md-3 plan_select">  <b>{Trans("PLAN_FEATURE", language)}</b></div>
           <div className="col-md-9 plan_select">
           <div className="row ">
                {planList &&
                  planList.map((plan, chid) => {
                    return (
                      <React.Fragment key={chid}>
                        <div className="col-md-4 border_right text-uppercase">
                          <b>{plan.subscription_plan_details?.plan_name}</b>
                        </div>
                      </React.Fragment>
                    );
                  })}
            </div>
            </div>
          </div>
         <div className="row">
             <div className="col-md-12">  
                    {sectionList &&
                    <>
                      {sectionList.map(
                        (subsection, idxx) => {
                          const {
                            feature_id,
                            
                            feature_title,
                            
                          } = subsection;
                          return(
                      <div className="row plan_select">
                      <div className="col-md-3 plan_select">
                     
                      <label className="">
                     
                        <h6>{feature_title}</h6>
                                           
                      </label>
             
                        </div>    
                    <div className="col-md-9">
                      <div className="row">
                        {subsection.feature_status &&
                         subsection.feature_status.map((ch, chid) => {
                            const {
                                id,
                                
                                status,
                                
                              } = ch;

                            return (
                              
                              <div key={chid} className="col-md-4 plan_select d-flex justify-content-between align-items-center">

                                <select
                                  {...register(

                                    `status_${ch.plan_id}_${feature_id}`
                                  )}
                                  className=""
                                  defaultValue={statuslist}
                                >
                                 
                            <option value="yes"> {Trans("yes", language)} </option>
                            <option value="no"> {Trans("no", language)} </option>
                                
                                </select>

                                <FormGroup  className="mb-0">
                             <input
                              id="name"
                              type="text"
                              className="form-controls"
                              placeholder="FEATURE_LIMIT"
                              {...register("feature_limit", {
                               
                              })}
                            />
                           
                          </FormGroup>
                              </div>
                            
                            );
                          })}
       
                      </div>
                    </div>
                    </div>  
                 );
                })}
                 </> }   
                  
                    </div>
               
          </div>
        </React.Fragment>
      )}
    </React.Fragment>
  );
};

export default PermissionUI;
