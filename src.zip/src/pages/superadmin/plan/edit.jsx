import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { planUpdateUrl, planEditUrl, industryUrlAll } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  Label,
  IsFeatured,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Select from "react-select";
import Loading from "component/Preloader";
import MyEditor from "component/MyEditor";
import { ErrorMessage } from "@hookform/error-message";


const Edit = (props) => {
  const { editData } = props;

  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
  } = useForm();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    saveFormData.industry_id = MultiSelectItem;

    POST(planUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
             const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [moduleList, SetmoduleList] = useState([]);
  const [defaultSelectValue, SetDefaultSelectValue] = useState();

 

    const setValueToField = () => {
      const editInfo = {
        api_token: apiToken,
        plan_id: editData,
      };
      POST(planEditUrl, editInfo)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          SetmoduleList(data.industry_list);

            const fieldList = getValues();
          for (const key in fieldList) {
            setValue(key, data.data_list[key]);
          }
          //setting edit info to show select value


          const module = data?.data_list.plan_to_industry;
          let selectedItem = [];
          let arraySizeSingle = [];
          if (module.length > 0) {
            for (let index = 0; index < module.length; index++) {
              selectedItem.push({
                label: module[index].industry_name,
                value: module[index].industry_id,
              });
              arraySizeSingle.push(module[index].industry_id);
            }
          }

          SetMultiSelectItem(arraySizeSingle.join(","));
          SetDefaultSelectValue(selectedItem);
        })
        .catch((error) => {
            SetloadingStatus(false);
          alert(error.message);
        });
    };

    useEffect(() => {
      let abortController = new AbortController();
      setValueToField();
      return () => {
        abortController.abort();
      };
    }, []);


  

  const [MultiSelectItem, SetMultiSelectItem] = useState("");
  const handleMultiSelectChange = (newValue, actionMeta) => {
    console.log("newValue", newValue);
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    listArr = listArr.join(",");
    console.log("listArr", listArr);
    SetMultiSelectItem(listArr);
    console.log("actionMeta", actionMeta);
  };

  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible
            >
              {error.msg}
            </Alert>
          )}
          <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
            <input type="hidden" {...register("plan_id")} />
            <Row>

            {defaultSelectValue && (
                 <Col col={12}>
                 <FormGroup mb="20px">
                   <Label
                     display="block"
                     mb="5px"
                     htmlFor={Trans("INDUSTRY", language)}
                   >
                     {Trans("INDUSTRY", language)}
                   </Label>
                   <Select
                     isMulti
                     name={Trans("INDUSTRY", language)}
                     options={moduleList}
                     defaultValue={defaultSelectValue}
                     className="basic-multi-select"
                     classNamePrefix="select"
                     onChange={handleMultiSelectChange}
                   />
                 </FormGroup>
               </Col>


              )}
              <Col col={12}>
                <FormGroup mb="20px">
                  <Input
                    id={Trans("PLAN_NAME", language)}
                    label={Trans("PLAN_NAME", language)}
                    placeholder={Trans("PLAN_NAME", language)}
                    hint="Enter text" // for bottom hint
                    className="form-control"
                    {...register("plan_name", {
                      required: Trans("PLAN_NAME_REQUIRED", language),
                    })}
                  />
                   <span className="required">
                <ErrorMessage errors={errors} name="plan_name" />
              </span>
                </FormGroup>
              </Col>
             
              <Col col={12}>
                <FormGroup>
                  <Label>{Trans("PLAN_DESC", language)}</Label>
                  <MyEditor
                    setKey={`plan_desc`}
                    setVal={
                      getValues(`plan_desc`) === undefined
                        ? "<p></p>"
                        : getValues(`plan_desc`)
                    }
                    updateFun={(Key, Value) => {
                      setValue(Key, Value);
                    }}
                  />
                  <textarea
                    {...register(`plan_desc`)}
                    style={{ display: "none" }}
                  ></textarea>
                </FormGroup>
              </Col>

          
              <Col col={6}>
                <FormGroup mb="20px">
                  <StatusSelect
                    id={Trans("STATUS", language)}
                    label={Trans("STATUS", language)}
                    hint="Enter text" // for bottom hint
                    className="form-control"
                    {...register("status", {
                      required: Trans("STATUS_REQUIRED", language),
                    })}
                  />
                </FormGroup>
              </Col>
              <Col col={6}>
                <FormGroup mb="20px">
                  <IsFeatured
                    id={Trans("IS_FEATURED", language)}
                    label={Trans("IS_FEATURED", language)}
                    className="form-control"
                    {...register("featured", {
                      required: Trans("IS_FEATURED_REQUIRED", language),
                    })}
                  />
                </FormGroup>
              </Col>
            

         
              <Col col={4}>
                <LoaderButton
                  formLoadStatus={formloadingStatus}
                  btnName={Trans("UPDATE", language)}
                  className="btn btn-primary btn-block"
                />
              </Col>
            </Row>
          </form>
        </>
      )}
    </>
  );
};

export default Edit;
