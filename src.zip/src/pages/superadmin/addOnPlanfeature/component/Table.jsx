import React from "react";
import CheckPermission from "helper";
import FeatherIcon from "feather-icons-react";
import {
  BadgeShow,
  Col,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalAlert from "component/ModalAlert";
import { useState } from "react";
import { PreUpdate, PreRemove, PreView } from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import { SettingGroup } from "config/WebsiteUrl";

function Table({
  dataList,
  deleteFun,
  pageName,
  filterItem,
  editFun,
  viewFunction,
  updateStatusFunction,
  approvalStatus,
  UpdateSortOrder
}) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deleteFun,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  // change Status function
  const ChangeStatus = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: updateStatusFunction,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const editFunction = (editId) => {
    editFun(editId);
  };

  const viewFun = (editId) => {
    viewFunction(editId);
  };
  const statusColor = ["danger",  "success", "warning","info" ];

  const StatusChange = (quoteId, statusId) => {
    updateStatusFunction(quoteId, statusId);
  };

console.log(dataList);
  var set2 = new Set();
  {
    dataList &&
      dataList.map((template, idx) => {
        set2.add(template.featureGroup);
      });
  }
  console.log(set2);
  let arrayhead = [...set2];

  let ar1;
  let bigar = new Set();
  {
    for (let i = 0; i < arrayhead.length; i++) {
      ar1 = [];

      for (let j = 0; j < dataList.length; j++) {
        if (dataList[j].featureGroup == arrayhead[i]) {
          ar1.push(dataList[j]);
        }
      }
      bigar.add(ar1);
    }
    console.log(bigar);
  }
  let arraylist = [...bigar];
  console.log(arraylist, "arraylist");

  return (
    <>
      <Col col={12}>
      <div className="row row-xs">
          <div className="col-sm-12 col-lg-12">
            <div className="" id="">
              {arrayhead &&
                arrayhead.map((head, index) => {
                  return (
                    <div
                      className="card"
                      id="custom-user-list"
                      style={{ marginBottom: "25px" }}
                    >
                      <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                        <h6 className="tx-uppercase tx-semibold mg-b-0">
                          {head}
                        </h6>
                      </div>
                      <div className="table-responsive">
                        <table
                          className="table"
                          style={{ border: "none", borderCollapse: "inherit" }}
                        >
                          <thead>
                            <tr>
                            <th  style={{
                                  border: "none",
                                }}>{Trans("SL_NO", language)}</th>
                            <th  style={{
                                  border: "none",
                                }}>{Trans("FEATURE_TITLE", language)}</th>
                            {/* <th  style={{
                                  border: "none",
                                }}>{Trans("INDUSTRY", language)}</th> */}
                            <th  style={{
                                  border: "none",
                                }}>{Trans("SORT_ORDER", language)}</th>
                            <th  style={{
                                  border: "none",
                                }}>{Trans("STATUS", language)}</th>
                             
                              <th
                                className="text-center"
                                style={{
                                  border: "none",
                                }}
                              >
                                {Trans("ACTION", language)}
                              </th>
                            </tr>
                          </thead>

                          {arraylist &&
                            arraylist.map((e, idx) => {
                              return e.map((template) => {
                                const {
                               feature_id,
                               Industry,
                                feature_title,
                                feature_details,
                                featureGroup,
                                status,
                                sort_order,

                                } = template;
                                return featureGroup == head ? (
                                  <tbody>
                                    <tr>
                                      <td>{feature_id}</td>

                                      <td>{feature_title}</td>
                                      {/* <td>{ Industry ==1  ? 'E-commerce'  : Industry ==2 ? 'Service' : Industry ==3 ? 'Enterprse' : 'Business' }</td>
  */}
                                      <td> <input
                                    type="number"
                                    name=""
                                    id=""
                                    defaultValue={sort_order}

                                    style={{ width: "50px" , 'text-align':"center"}}                               
                                    onBlur={(e) => {
                                      UpdateSortOrder(
                                        feature_id,
                                      e.target.value
                                    );
                                }}
                                />
                            </td>

                                    
                        <td>
                        <BadgeShow
                            type={status === 1 ? "success" : "danger"}
                            content={status === 1 ? "Active" : "Deactive"}
                          />
                        </td>
                        <td className="text-center">
                          <CheckPermission
                            PageAccess={pageName}
                            PageAction={PreUpdate}
                          >

                            <button className="btn btn-primary  btn-xs btn-icon">
                                      <FeatherIcon
                                        icon="edit-2"
                                        fill="white"
                                        size={20}
                                        onClick={() =>editFunction(feature_id)}
                                      />
                              </button>
                          
                              </CheckPermission>
                            {"  "}
                          <button className="btn btn-primary btn-xs btn-icon   ">
                            <FeatherIcon
                              icon="repeat"
                              fill="white"
                              onClick={() =>ChangeStatus(feature_id)}
                            />
                        </button>
                         
                        
                        </td>


                                    </tr>

                                    
                                  </tbody>
                                ) : (
                                  ""
                                );
                              });
                            })}
                          {/* {dataList.length > 0 &&
                dataList.map((cat, IDX) => {
                  const {
                    plan_id,
                    plan_name,
                    industry_name,
                    status,
                   
                  } = cat;
                  rowId++;
                  return (
                    <React.Fragment key={IDX}>
                      <tr>
                        <td>{rowId}</td>

                        <td>{plan_name}</td>
                        <td>{industry_name}</td>
                       
                        <td>
                          <BadgeShow
                            type={status === 1 ? "success" : "danger"}
                            content={status === 1 ? "Active" : "Deactive"}
                          />
                        </td>
                        <td className="text-center">
                          <Anchor
                            color="primary"
                            path={WebsiteLink(
                              `/plan/view/${plan_id}`
                            )}
                          >
                            <button className="btn btn-primary ">
                              <FeatherIcon icon="eye" color="white"   />
                            </button>
                          </Anchor>{" "}
                          <CheckPermission
                            PageAccess={pageName}
                            PageAction={PreUpdate}
                          >
                           
                               <button className="btn btn-primary ">
                              <FeatherIcon
                                icon="edit-2"
                                fill="white"
                                size={20}
                                onClick={() =>editFunction(plan_id)}
                              />
                              </button>
                          
                          </CheckPermission>
                          {"  "}
                          <button className="btn btn-primary ">
                            <FeatherIcon
                              icon="repeat"
                              fill="white"
                              onClick={() =>ChangeStatus(plan_id)}
                            />
                        </button>
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })} */}
                        </table>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        </div>
      </Col>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </>
  );
}

export default Table;
