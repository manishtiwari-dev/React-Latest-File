import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import Select from "react-select";

import {
  AddOnPlanFeatureUpdateUrl,
  AddOnPlanFeatureEditUrl,
  industryCreateList,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  StatusSelect,
  Label,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import Loading from "component/Preloader";
import { ErrorMessage } from "@hookform/error-message";


const Edit = (props) => {
  console.log("edit props");
  console.log(props);

  const { editData } = props;

  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    getValues,
  } = useForm();












    
  const [selectedIndustry, SetSelectedIndustry] = useState();
  const [IndustryTypeList, SetIndustryTypeList] = useState();

  const [MultiSelectCategoryItem, SetMultiSelectCategoryItem] = useState([]);
  const handleMultiSelectChange = (newValue, actionMeta) => {
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    SetMultiSelectCategoryItem(listArr);
  };

  const getModuleList = () => {
    const filterData2 = {
      api_token: apiToken,
    };
    POST(industryCreateList, filterData2)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetIndustryTypeList(data.IndustryTypeList);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    getModuleList();
    return () => abortController.abort(); //getModuleList();
  }, []);

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [selectedCountryList, SetselectedCountryList] = useState("");
  const [moduleList, SetmoduleList] = useState([]);
  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
    
    POST(AddOnPlanFeatureUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
             const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    function setValueToField() {
      const editInfo = {
        api_token: apiToken,
        feature_id: editData,
      };
      POST(AddOnPlanFeatureEditUrl, editInfo)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          const fieldList = getValues();
          for (const key in fieldList) {
            setValue(key, data[key]);
          }

          SetSelectedIndustry(data.selected_feature);

          let listArr = [];
          if (data?.selected_feature?.length > 0) {
            for (
              let index = 0;
              index < data?.selected_feature.length;
              index++
            ) {
              listArr[index] = data?.selected_feature[index].value;
            }
          }
          SetMultiSelectCategoryItem(listArr);

        })
        .catch((error) => {
            SetloadingStatus(false);
          alert(error.message);
        });
    }
    setValueToField();
    return () => {
      // setValueToField();
      abortController.abort();
    };
  }, []);




 


  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible
            >
              {error.msg}
            </Alert>
          )}

          <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
            <input type="hidden" {...register("feature_id")} />
           
            <Row>



            {/* <Col col={6}>
            <FormGroup>
              <Label display="block" mb="5px" htmlFor="name">
                {Trans("FEATURE_GROUP", language)} <span className="required">*</span>
              </Label>
              <select
                id={Trans("FEATURE_GROUP", language)}
                placeholder={Trans("FEATURE_GROUP", language)}
                className="form-control"
                {...register("feature_group")}
               
              >
                <option value=" ">{Trans("SELECT_FEATURE_GROUP", language)}</option>
                <option value="1"> {Trans("Website", language)} </option>
                <option value="2">{Trans("Backend", language)} </option>
                <option value="3"> {Trans("Marketing", language)} </option>
               
              </select>
           
            </FormGroup>
          </Col> */}




          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("FEATURE_TITLE", language)}
                label={Trans("FEATURE_TITLE", language)}
                placeholder={Trans("FEATURE_TITLE", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("feature_title", {
                  required: Trans("FEATURE_TITLE_REQUIRED", language),
                })}
              />
                <span className="required">
                <ErrorMessage errors={errors} name="feature_title" />
              </span>
              
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("FEATURE_DETAIL", language)}
                label={Trans("FEATURE_DETAIL", language)}
                placeholder={Trans("FEATURE_DETAIL", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("feature_details", {
                 
                })}
              />
             
            </FormGroup>
          </Col>

          {/* <Col col={6}>
                <FormGroup mb="20px">
                  <Input
                    type="hidden"
                    id={Trans("INDUSTRY", language)}
                    label={Trans("INDUSTRY", language)}
                    placeholder={Trans("INDUSTRY", language)}
                    className="form-control"
                    {...register("industry_id")}
                  />

                  {selectedIndustry && (
                    <Select
                      isMulti
                      defaultValue={selectedIndustry}
                      name={Trans("CATEGORY", language)}
                      options={IndustryTypeList}
                      className="basic-multi-select"
                      classNamePrefix="select"
                      onChange={handleMultiSelectChange}
                    />
                  )}
                </FormGroup>
              </Col> */}

          <Col col={6}>
            <FormGroup mb="20px">
              <StatusSelect
                id={Trans("STATUS", language)}
                label={Trans("STATUS", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("status", {
                  required: Trans("STATUS_REQUIRED", language),
                })}
                defaultValue={1}
              />
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("SORT_ORDER", language)}
                type="number"
                label={Trans("SORT_ORDER", language)}
                placeholder={Trans("SORT_ORDER", language)}
                className="form-control"
                {...register("sort_order", {
                  required: Trans("SORT_ORDER_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="sort_order" />
              </span>
            </FormGroup>
          </Col>
         
          <Col col={4}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("UPDATE", language)}
              className="btn btn-primary btn-block"
            />
          </Col>
        </Row>
          </form>
        </>
      )}
    </>
  );
};

export default Edit;
