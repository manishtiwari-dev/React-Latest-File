import React from "react";
import Currency from "hooks/currency";
import { Trans } from "lang";
import { BadgeShow } from "component/UIElement/UIElement";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { useState } from "react";

import Moment from "react-moment";
import Notify from "component/Notify";

import POST from "axios/post";
import Chart from "react-apexcharts";
// import ReactFlot from 'react-flot';

import Content from "layouts/content";

import PageHeader from "component/PageHeader";

import { DashboardUrl } from "config/index";

import { Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";

function SalesDashboardModel({ dashboardcontent }) {
  // console.log("transactionLog", JSON.parse(dashboardcontent));
  const [transaction, setTransaction] = useState([]);
  const { apiToken, language } = useSelector((state) => state.login);
  useEffect(() => {
    let abortController = new AbortController();

    setTransaction(JSON.parse(dashboardcontent));
    return () => abortController.abort();
  }, [dashboardcontent]);

  console.log(transaction);

  return (
    <div className="row">
      <div className="col-md-12">
        <div className="">
          <div className="d-flex">
            <h6>{Trans("PRIORITY", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.priority}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("STATUS", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.status}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("CLOSE_DATE", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.close_date}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("ADDED_BY", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.added_by}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("DELETED_AT", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.deleted_at}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("TRANSACTION_NUMBER", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.transaction_no}</p>
          </div>
          <div className="d-flex">
            <h6>{Trans("PAYMENT_STATUS", language)} : &nbsp; &nbsp;</h6>
            <p>{transaction.payment_status}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SalesDashboardModel;
