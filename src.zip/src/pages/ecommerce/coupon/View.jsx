import React from "react";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { couponviewUrl } from "config";
import Notify from "component/Notify";

import POST from "axios/post";

function View({ editId }) {
  const [dataList, SetdataList] = useState();
  const getData = () => {
    const filterData = {
      api_token: apiToken,
      coupon_id: editId,
    };
    POST(couponviewUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetdataList([data]);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };
  useEffect(() => {
    let abortController = new AbortController();

    getData();
    return () => abortController.abort();
  }, []);
  const { role, apiToken, userType, language, industry } = useSelector(
    (state) => state.login
  );
  return (
    <div className="row">
      <div className="col-md-12">
        {dataList &&
          dataList.map((e) => {
            return (
              <div className="">
                <div className="table-responsive">
                  {dataList &&
                    dataList.map((e, indx) => {
                      const { coupon_id } = e;

                      return (
                        <table
                          className="table mb-4"
                          style={{ borderCollapse: "collapse" }}
                        >
                          <tr>
                            <td className="text-center">
                              {Trans("NUMBER_OF_USER_ELIGIBLE", language)}
                            </td>
                            <td className="text-center">{e.multiple_use}</td>
                          </tr>
                          <tr>
                            <td className="text-center">
                              {Trans("COUPON_CODE", language)}
                            </td>
                            <td className="text-center">{e.coupon_code}</td>
                          </tr>

                          <tr>
                            <td className="text-center">
                              {Trans("LIMIT_PER_PERSON", language)}
                            </td>

                            <td className="text-center">{e.coupon_limit}</td>
                          </tr>

                          <tr>
                            <td className="text-center">
                              {Trans("DISCOUNT_TYPE", language)}
                            </td>
                            <td className="text-center">
                              {" "}
                              {e.discount_type === 1 ? "Price" : "Percent"}
                            </td>
                          </tr>

                          <tr>
                            <td className="text-center">
                              {Trans("DISCOUNT_AMOUNT", language)}{" "}
                            </td>
                            <td className="text-center">{e.discount}</td>
                          </tr>
                          <tr>
                            <td className="text-center">
                              {Trans("MAXIMUM_DISCOUNT", language)}
                            </td>
                            <td className="text-center">
                              {e.maximum_discount}
                            </td>
                          </tr>
                          <tr>
                            <td className="text-center">
                              {Trans("MINIMUM_PURCHASES", language)}
                            </td>
                            <td className="text-center">
                              {e.minimum_purchase}
                            </td>
                          </tr>
                        </table>
                      );
                    })}
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
}

export default View;
