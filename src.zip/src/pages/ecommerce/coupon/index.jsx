import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import DataTable from 'react-data-table-component';

import {
  couponUrlAll,
  couponChangeStatusUrl,
  languageDeleteUrl,
  coupondeleteUrl,
} from "config";
import { moduleChangeStatusUrl, moduleUpdateSortOrderUrl } from "config/index";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
} from "component/UIElement/UIElement";
import POST from "axios/post";
import { useSelector, useDispatch } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import Pagination from "component/pagination/index";
import ExportButton from "component/ExportButton";
import SearchBox from "component/SearchBox";
import RecordPerPage from "component/RecordPerPage";
import TreeComponent from "pages/module/component/index/TreeComponent";
import { Badge, IconButton, Anchor } from "component/UIElement/UIElement";

import { Modal, Button } from "react-bootstrap";
import View from "./View";
import Edit from "./Edit";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { PageCoupon, PreAdd, PreView, PreExport } from "config/PermissionName";
// import SubModuleEdit from "./component/index/SubModuleEdit";

import { updateModuleListState } from "redux/slice/loginSlice";

import Add from "./Add";

function Index() {
  const { apiToken, language } = useSelector((state) => state.login);
  const [dataList, SetdataList] = useState([]);
  const [Pagi, SetPagi] = useState(0);
  const [currPage, SetcurrPage] = useState(0);
  const [searchItem, SetSEarchItem] = useState("");
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");
  const [perPageItem, SetPerPageItem] = useState(10);

  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        const per = Number(value);
        SetPerPageItem(per);
        getData(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        getData(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        getData(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        getData(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        getData(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };
  const getData = (pagev, perPageItemv, searchData, sortBys, OrderBy) => {
    // SetloadingStatus(true);
    const filterData = {
      api_token: apiToken,
      page: pagev,
      perPage: perPageItemv,
      search: searchData,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(couponUrlAll, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          // SetloadingStatus(false);
          SetdataList(data.data);
          SetPagi(data.total_page);
          SetcurrPage(data.current_page);
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  useEffect(() => {
    let abortController = new AbortController();

    getData(1, perPageItem, searchItem, sortByS, orderByS);
    return () => abortController.abort();
  }, []);


  const [addModuleShow, setAddModuleShow] = useState(false);
  const handleModalClose = () => setAddModuleShow(false);
  const handleModalShow = () => setAddModuleShow(true);

  const [addSubModuleShow, SetSubAddModuleShow] = useState(false);
  const handleSubModuleModalClose = () => SetSubAddModuleShow(false);
  const handleSubModuleModalShow = () => SetSubAddModuleShow(true);

  const deleteItem = (deleteID) => {
    const infoData = {
      api_token: apiToken,
      coupon_id: deleteID,
    };
    POST(coupondeleteUrl, infoData)
      .then((response) => {
        const { message } = response.data;
        filterItem("refresh", "", "");
        getData(1, perPageItem, searchItem, sortByS, orderByS);
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };
  const [subeditdata, SetsubEditData] = useState();
  const [editSubmodule, SeteditSubmodule] = useState(false);
  const handleeditSubModuleModalClose = () => SetsubEditData(false);
  const handleeditSubModuleModalShow = () => SetsubEditData(true);

  const StatusChnageFun = (edit_id, status) => {
    const editData = {
      api_token: apiToken,
      coupon_id: edit_id,
      status: status,
    };
    POST(couponChangeStatusUrl, editData)
      .then((response) => {
        const { message, data } = response.data;
        // update side module and section
        getData(1, perPageItem, searchItem, sortByS, orderByS);

        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const RefreshList = () => {
    filterItem("refresh", "", "");
  };

  const [Displaceholder, Setdisplaceholder] = useState("");
  const discountshow = (e) => {
    // Sdiscountamtbox(true);
    Setdisplaceholder(e);
  };
  const {
    register,
    formState: { errors },
    handleSubmit,
    setValue,
  } = useForm();

  const [editid, Seteditid] = useState();
  let date;
  const columns = [
    {
    
        name:(`${Trans("SL_NO", language)}`),
        selector: row => row.coupon_id,
        sortable: true,
    },
    {
    
      name:(`${Trans("COUPON_NAME", language)}`),
      selector: row => row.coupon_name,
      sortable: true,
    },
  {
    
    name:(`${Trans("COUPON_CODE", language)}`),
    selector: row => row.coupon_code,
    sortable: true,
},

{
    
  name:(`${Trans("EXPIRY_DATE", language)}`),
  selector: row => row.expire_at,
  sortable: true,
},


// {
    
//   name:(`${Trans("STATUS", language)}`),
//   selector: row => row.expire_at,
// },

    {
        name: 'Action',
        sortable: true,
        selector :(row) =>
        
        (
         <IconButton onClick={() => {
          Seteditid(row.coupon_id);
          handleSubModuleModalShow();
        }}>
         <FeatherIcon
          size={20}
          onClick={() => {
            Seteditid(row.coupon_id);
            handleSubModuleModalShow();
            // gdta(indx);
          }}
          icon="eye"
          // fill="white"
          className="wd-10 mg-r-6"
          // id={indx}
           /> 
            </IconButton>  
            
      

        ),
        
        selector :(row)=>(
          <IconButton
          color="primary"
          onClick={() => {
            handleeditSubModuleModalShow();
            // gdta(indx);
          }}
        >
          <FeatherIcon
            size={20}
            onClick={() => {
              Seteditid(row.coupon_id);
              handleeditSubModuleModalShow();
              // gdta(indx);
            }}
            icon="edit-2"
            // fill="white"
            className="wd-10 mg-r-6"
            // id={indx}
          />
        </IconButton>
        ),
        
        
    },
];

// {
//   name: 'Action',
//   selector: row => (`${<IconButton   color="primary"
//   onClick={() => {
//     Seteditid(row.coupon_id);
//     handleSubModuleModalShow();
//   }}> 
  
// (`${<FeatherIcon
//   onClick={() => {
//     Seteditid(row.coupon_id);
//     handleSubModuleModalShow();
//   }}
//   size={20}
//   icon="eye"
//   // fill="white"
//   className="wd-10 mg-r-6"
// />
// }`)
// </IconButton>}`) ,
// },




  return (
    <Content>
     
      <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <CheckPermission
             PageAccess={PageCoupon} PageAction={PreView} 
            >
            <div className="card" >
              <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                <h6 className=" tx-semibold mg-b-0">
                  {Trans("COUPON_LIST", language)}
                </h6>
                <div className="d-none d-md-flex">
        
        
        
                  <CheckPermission
                     PageAccess={PageCoupon} PageAction={PreAdd} >
                    <Button variant="primary" onClick={handleModalShow}>
                      <FeatherIcon
                        icon="plus"
                        fill="white"
                        className="wd-10 mg-r-6"
                      />
                      {Trans("ADD_COUPON", language)}
                    </Button>
                  </CheckPermission>
                </div>
              </div>

              <div className="card-body">
                {/* <div className="d-flex mb-3">
                  <div className="">
                 
                    <RecordPerPage
                      filterItem={filterItem}
                      perPageItem={perPageItem}
                    />
                  </div>
                  &nbsp;&nbsp;
                  <div className="">
                   
                  </div>
                </div> */}

             
                <DataTable
                  columns={columns}
                  data={dataList}
                  pagination
                  responsive
                  selectableRows
                 subHeader
                 subHeaderComponent= {
                 <SearchBox filterItem={filterItem} />
                 }
                
                  />
{/* 
                  <Pagination
                    totalPage={Pagi}
                    currPage={currPage}
                    filterItem={filterItem}
                  /> */}
              
              </div>
            </div>
          </CheckPermission>
        </div>
      </div>
      <Modal
        show={addSubModuleShow}
        onHide={() => {
          handleSubModuleModalClose();
        }}
        size=""
      >
        <Modal.Header>
          <Modal.Title>{Trans("VIEW_COUPON", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              handleSubModuleModalClose();
              // SetEditId(e.)
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <View editId={editid} />
        </Modal.Body>
      </Modal>

      <Modal
        show={addModuleShow}
        onHide={() => {
          handleModalClose();
        }}
      >
        <Modal.Header>
          <Modal.Title>{Trans("ADD_COUPON", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              handleModalClose();
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Add filterItem={filterItem} handleModalClose={handleModalClose} />
        </Modal.Body>
      </Modal>

      <Modal
        show={subeditdata}
        onHide={() => {
          handleeditSubModuleModalClose();
        }}
      >
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_COUPON", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              handleeditSubModuleModalClose();
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editid}
            filterItem={filterItem}
            handleModalClose={handleeditSubModuleModalClose}
          />
        </Modal.Body>
      </Modal>
    </Content>
  );
}

export default Index;
