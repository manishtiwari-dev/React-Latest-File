import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { Anchor } from "component/UIElement/UIElement";

import { Trans } from "lang/index";
import { productShowUrl ,productChangeStatusUrl} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import Notify from "component/Notify";
import WebsiteLink from "config/WebsiteLink";


export default function Detail() {
  const findOptionName = (dataArray, findid) => {
    const attrname = dataArray.filter((data) => {
      return data.products_options_id === findid
        ? data.products_options_name
        : "";
    });
    return attrname.length > 0 ? attrname[0]["products_options_name"] : "";
  };

  const { proId } = useParams();

  let bod = new Array();
  let stringArray;
  let uniqueArray;
  const findOptionValueName = (dataArray, findid) => {
    let temp = new Array();
    var obj = {};
    dataArray.map((e) => {
      if (e.products_options_id == findid) {
        obj[e.products_options_values_id] = e.products_options_values_name;
      }
    });
    bod.push(obj);
  };

  const { product_id } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [DataList, SetDataList] = useState();
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);
  const [mainimg, setmainimg] = useState();
 
  const [EditData, setData] = useState();

  let stat;
  useEffect(() => {
 
    let abortController = new AbortController();
    const getData = () => {
      const editData = {
        api_token: apiToken,
        product_id: proId,
      };
      POST(productShowUrl, editData)
        .then((response) => {
          const { status, data, message } = response.data;
          if (status) {
            SetloadingStatus(false);
            SetDataList(data);
          } else alert(message);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
    };
    getData();

    return () => {
      // checkactive(DataList?.product_status);
      getData();
      abortController.abort();
    };
  }, [product_id]);

  {
    DataList?.product_status == "active"
      ? (stat = "green")
      : DataList?.product_status == "deactive"
      ? (stat = "danger")
      : (stat = "warning");
  }
  let optionAry = new Array();
  let valueAry = new Array();

  {
    DataList?.productAttribute &&
      DataList?.productAttribute.map((attr, idx) => {
        {
          
          const index = optionAry.findIndex(
            (element) =>
              element === findOptionName(attr.option_list, attr.options_id)
          );
          if (index !== -1) {
            //array1.push(findOptionName(attr.option_list, attr.options_id));
          } else {
            let valueName = [];
            optionAry.push(findOptionName(attr.option_list, attr.options_id));
            attr?.option_value_list.map((attrval, idx) => {
              valueName.push(attrval.products_options_values_name);
            });
            valueAry.push(valueName);
          }
        }
      });
  }



  const ChangeFunction = (update_id, statusId) => {
    const editData = {
      api_token: apiToken,
      update_id: update_id,
      statusId: statusId,
    };
    POST(productChangeStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
        // filterItem("refresh", "", "");
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const stSarr = ["Draft", "Active", "Inactive"];
  const stSarrC = ["warning", "success", "danger"];
  const StatusChange = (quoteId, statusId) => {
    ChangeFunction(quoteId, statusId);
  };

  
  useEffect(() => {
      document.title =" Product Show | WorkerMan";
    let abortController = new AbortController();
 
    return () => abortController.abort();
  }, []);

  return (
    <Content>
   {/* <PageHeader
        breadcumbs={[
          {
            title: Trans("DASHBOARD", language),
            link: WebsiteLink("/"),
            class: "",
          },
          {
            title: Trans("PRODUCT", language),
            link: WebsiteLink("/products"),
            class: "",
          },
     
        ]}
        // heading={Trans("VIEW_STAFF", language)}
      /> */}
    <div className="container-fluid mt-5 mb-5">
          <div className="row g-0">
            {DataList?.product_image && (
              <div className="col-md-4 border-end">
                <div className="d-flex flex-column justify-content-center">
                  <div className="product_carousel">
                   
                    <img
                      src={mainimg ? mainimg : DataList?.product_image}
                      id="main_product_image"
                      width="350"
                    />{" "}
                  </div>
                  <div className="thumbnail_images">
                    <ul id="thumbnail">
                      {DataList?.gallery_image.map((material, index = 1) => {
                        return (
                          <>
                            <li>
                              <img
                                onClick={() => setmainimg(material)}
                                src={material}
                                width="70"
                              />
                            </li>
                          </>
                        );
                      })}
                    </ul>
                  </div>
                </div>
                {DataList?.productdescription_with_lang && (
                  <>
                    {DataList?.productdescription_with_lang.map((oldlist) => {
                      return (
                        <div className="card mg-b-20 mg-lg-b-25">
                          <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                            <h6 className=" tx-semibold mg-b-0">
                            {Trans("PRODUCT_DESCRIPTION", language)}({oldlist.languages_name})</h6>
                          </div>
                         
                          <div className="card-body pd-25">
                         
                            <div className="media d-block d-sm-flex">
                              <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html:
                                      DataList?.productdescription[
                                        oldlist.languages_id - 1
                                      ]?.products_description,
                                  }}
                                ></div>
                              </div>
                            </div>
                          
                          </div>
                         
                        </div>
                      );
                    })}
                  </>
                )}
              </div>
            )}
            <div className="col-md-8">
              <div className="media-body mg-t-40 mg-lg-t-0 pd-lg-x-10">
                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans("PRODUCT_INFORMATION", language)}
                    </h6>
                    <div className="product_btn">
                    <Anchor
              path={WebsiteLink("/products/create")}
              className="btn btn-primary btn-sm"
            >
              {Trans("ADD_MORE_PRODUCT", language)}
            </Anchor>
            {"   "} {"  "} &nbsp;
            <Anchor
              path={WebsiteLink(
                `/products/edit/${DataList?.product_id}`
              )}
              className="btn btn-info btn-sm"
            >
              {Trans("EDIT_PRODUCT", language)}
            </Anchor>
            {"   "} {"  "} &nbsp;
            <Anchor
              path={WebsiteLink("/products")}
              className="btn btn-warning btn-sm"
            >
              {Trans("GO_BACK", language)}
            </Anchor>
                    </div>
                  
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="d-flex justify-content-between">
                          <div>
                            <h5 className="mb-0">
                              {DataList?.productdescription[0]?.products_name}
                            </h5>
                          </div>
                          <div>
                     
                              <>
                         <select
                            value={DataList?.product_status}
                            onChange={(e) => {
                              StatusChange(DataList?.product_id, e.target.value);
                            }}
                            className={`badge badge-${stSarrC[DataList?.product_status]}`}
                          >
                            <option value={0}>
                              {Trans("Draft", language)}
                            </option>
                            <option value={1}>
                              {Trans("Active", language)}
                            </option>
                            <option value={2}>
                              {Trans("Inactive", language)}
                            </option>
                          </select>
                               
                              </>
                          
                          </div>
                        </div>
                        <div className="table  table-dashboard">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                {DataList?.productdescription && (
                                  <>
                                    <td> {Trans("PRODUCT_NAME", language)}</td>
                                    <td>
                                      {
                                        DataList?.productdescription[0]
                                          ?.products_name
                                      }
                                    </td>
                                  </>
                                )}
                              </tr>
                              {DataList?.selected_category && (
                                <>
                                  {DataList.selected_category.map((list) => {
                                    return (
                                      <tr>
                                        <td>
                                          {" "}
                                          {Trans("Category :", language)}
                                        </td>
                                        <td>{list.label}</td>
                                      </tr>
                                    );
                                  })}
                                </>
                              )}
                              {DataList?.product_model && (
                                <tr>
                                  <td> {Trans("Model No :", language)}</td>
                                  <td> {DataList?.product_model}</td>
                                </tr>
                              )}
                              {DataList?.product_sku && (
                                <tr>
                                  <td> {Trans("PRODUCT_SKU", language)}</td>
                                  <td> {DataList?.product_sku}</td>
                                </tr>
                              )}
                              {DataList?.product_condition && (
                                <tr>
                                  <td>
                                  
                                  {Trans("PRODUCT_CONDITION", language)}
                                  </td>
                                  <td>
                                 
                                    {DataList?.product_condition == "1"
                                      ? "New"
                                      : "Refurbished"}
                                  </td>
                                </tr>
                              )}

              
                                {/* <tr>
                                  <td> {Trans("Profit Margin :", language)}</td>
                                  <td>{DataList?.product_profit_margin}</td>
                                </tr> */}
                           

                              {DataList?.product_discount_type && (
                                <tr>
                                  <td> {Trans("DISCOUNT_TYPE :", language)}</td>
                                  <td>{Trans(DataList?.product_discount_type, language)}</td>
                                </tr>
                              )}
                              {DataList?.product_discount_amount && (
                                <tr>
                                  <td>
                                    {Trans("PRODUCT_DISCOUNT_AMOUNT", language)}
                                  </td>
                                  <td>{DataList?.product_discount_amount}</td>
                                </tr>
                              )}
                              {DataList?.products_type_field_value.map((e) => {
                                return (
                                  <tr>
                                    <td> {Trans(e.field_label, language)} </td>
                                    <td>  {Trans(e.pivot.field_value, language)}</td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                  
                      <h6 className=" tx-semibold mg-b-0">
                        {Trans("PRODUCT_PRICE", language)}
                        
                      </h6>


                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                   
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellspacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                            
                 {/* //     {DataList?.product_price_type === 1 &&   */}
                      
                              {/* <tr>
                              <td> {Trans("PRODUCT_PRICE_TYPE", language)}</td>
                              <td> {DataList?.product_price_type ===1  ? 'Retail'  : ''}</td>
                              </tr> */}
                              <tr>
                              <td> {Trans("INVENTORY_PRICE", language)}</td>
                              <td> {DataList?.stock_price}</td>
                              </tr>
                          <tr>
                              <td> {Trans("PROFIT_PERCENT", language)}</td>
                              <td> {DataList?.profit_percent}</td>
                            </tr>
                      

                          <tr>
                            <td>{Trans("MAX_SALE_PRICE", language)}:</td>
                            <td> {DataList?.max_sale_price}</td>
                        </tr>

                          <tr>
                              <td>
                                      {Trans("PRODUCT_DISCOUNT_AMOUNT", language)}
                                    </td>
                                    <td>{DataList?.discount_amount}</td>
                                  </tr>

                          
                          <tr>
                            <td>{Trans("SELL_PRICE", language)}:</td>
                            <td> {DataList?.sale_price}</td>
                        </tr>

                        <tr>
                            <td>{Trans("ADDITIONAL_SHIPPING_CHARGE", language)}:</td>
                            <td> {DataList?.shipping_charge}</td>
                        </tr>

                      
              

{/* 
                               
              {DataList?.product_price_type === 2 &&  
                            <>
                            <tr>
                            <td> {Trans("PRODUCT_PRICE_TYPE", language)}</td>
                            <td> {DataList?.product_price_type ===2  ? 'Wholesale'  : ''}</td>
                            </tr>

                            {DataList?.product_price.map((e) => {
                                return (
                                  <>
                                  <tr>
                                    <td> {Trans("QTY", language)} </td>
                                    <td>  {Trans(e.product_qty, language)}</td>
                                  </tr>
                                    <tr>
                                    <td> {Trans("INVENTORY_PRICE", language)} </td>
                                    <td>  {Trans(e.stock_price, language)}</td>
                                  </tr>

                                  <tr>
                                    <td> {Trans("PROFIT_PERCENT", language)} </td>
                                    <td>  {Trans(e.profit_percent, language)}</td>
                                  </tr>

                                    <tr>
                                    <td> {Trans("MAX_SALE_PRICE", language)} </td>
                                    <td>  {Trans(e.max_sale_price, language)}</td>
                                  </tr> 

                                 <tr>
                                    <td> {Trans("DISCOUNT_PERCENT", language)} </td>
                                    <td>  {Trans(e.discount_percent, language)}</td>
                                  </tr>   


                                 <tr>
                                    <td> {Trans("FINAL_SALE_PRICE", language)} </td>
                                    <td>  {Trans(e.sale_price, language)}</td>
                                  </tr>      


                                  
                              </>  );
                              })}


                       </>
                    }
                       */}
                            
                            
                    

                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans("PRODUCT_ATTRIBUTE_INFO", language)}
                    </h6>
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              {optionAry && (
                                <>
                                  {optionAry.map((e, ind) => {
                                    const linkContent = valueAry[ind];
                                    console.log(e);
                                    return (
                                      <>
                                        <tr>
                                          <td>{e}</td>
                                          <td>
                                            <ul className="pd-l-10 mg-0 mt-2 tx-13">
                                              {linkContent.map((e) => {
                                                return( <>
                                                <li>{e}
                                                {/* <ul>
                                                <li>{e}</li></ul> */}
                                                </li>
                                                </>);
                                              })}
                                            </ul>
                                          </td>
                                        </tr>

                                       
                                      </>
                                    );
                                  })}
                                  {/* {valueAry.map((student) => {
                                      return <td> {student}</td>;
                                    })} */}

                                </>
                                // </tr>
                              )}

                                   {/* <tr>
                                          <td>{Trans("OPTION_VALUE_PRICE", language)}</td>
                                          <td>
                                            <ul className="pd-l-10 mg-0 mt-2 tx-13">
                                            {DataList?.productAttribute.map((e) => {
                                return (
                                 
                                    <li>  {Trans(e.options_values_price, language)}</li>
                                 
                                );
                              })}





                                            </ul>
                                          </td>
                                        </tr> */}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card mg-b-20 mg-lg-b-25">
                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                    {Trans("PRODUCT_FEATURE", language)}
                      
                    </h6>
                  </div>
                  <div className="card-body pd-25">
                    <div className="media d-block d-sm-flex">
                      <div className="media-body pd-t-25 pd-sm-t-0 pd-sm-l-25">
                        <div className="table-responsive">
                          <table
                            className="products_details"
                            cellSpacing="0"
                            rules="all"
                            border="1"
                            id="ContentPlaceHolder1_gvAttr"
                            style={{ borderCollapse: "collapse" }}
                          >
                            <tbody>
                              <tr>
                                <>
                                  {DataList?.product_feature.map((lit) => {
                                    return (
                                      <td>{`${lit.feature_title}  :  ${lit.feature_value}`}</td>
                                    );
                                  })}
                                </>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

               <div className="table-responsive mg-t-40">
            <table className="table table-invoice bd-b">
              <thead>
                <tr>
                  <th className="tx-left">{Trans("SL_NO", language)}</th>
              
                  <th className="tx-center">{Trans("QTY", language)}</th>
                  <th className="tx-center">{Trans("INVENTORY_PRICE", language)}</th> 
                  <th className="tx-center">{Trans("PROFIT_PERCENT", language)}</th>
                  <th className="tx-center">{Trans("MAX_SALE_PRICE", language)}</th>
                  <th className="tx-center">{Trans("DISCOUNT", language)}</th>
                  <th className="tx-right">{Trans("FINAL_SALE_PRICE", language)}</th>
                </tr>
              </thead>
              <tbody>
              {DataList?.product_price.map((e,idx) => {
                       
                  return (
                    <tr key={idx}>
                      <td className="tx-left">{idx + 1}</td>
                      <td className="tx-center">  {Trans(e.product_qty, language)}</td>
                      <td>  {Trans(e.stock_price, language)}</td>
                      <td>  {Trans(e.profit_percent, language)}</td>
                      <td>  {Trans(e.max_sale_price, language)}</td>
                       <td>  {Trans(e.discount_percent, language)}</td>
                       <td>  {Trans(e.sale_price, language)}</td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>



              </div>
            </div>
          </div>
      </div>
      </Content>
   
  );
}
