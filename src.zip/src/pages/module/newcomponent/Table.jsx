import React, { useEffect, useState } from "react";
import "../style.css";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { moduleUrl, languageDeleteUrl } from "config";
import { moduleChangeStatusUrl, moduleUpdateSortOrderUrl,moduleSectionSourceUrl } from "config/index";
import ColorInfo from "../component/index/ColorInfo";

import POST from "axios/post";
import { useSelector, useDispatch } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import Pagination from "component/pagination/index";
import ExportButton from "component/ExportButton";
import SearchBox from "component/SearchBox";
import RecordPerPage from "component/RecordPerPage";
import TreeComponent from "pages/module/component/index/TreeComponent";

import { Modal, Button } from "react-bootstrap";
import AddModule from "../AddModule";
import AddSubModule from "../AddSubModule";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { PageModule, PreAdd, PreView, PreUpdate } from "config/PermissionName";
import SubSectionEdit from "../component/index/SubModuleEdit";
import ModuleEdit from "../component/index/ModuleEdit";
import { updateModuleListState } from "redux/slice/loginSlice";

function Table({ dataList, filterItem }) {
  const dispatch = useDispatch();
  const { apiToken, language } = useSelector((state) => state.login);
  const AccessColor = ["#ff8d00", "#001737", "#7a00ff"];

  const GlobeColor = ["blue", "#ff8d00", "dark", "green"];
  const [subeditdata, SetsubEditData] = useState();
  const [editSubmodule, SeteditSubmodule] = useState(false);
  const [editId, SetEditId] = useState();
  const [addModuleShow, setAddModuleShow] = useState(false);
  const [addSubModuleShow, SetSubAddModuleShow] = useState(false);

  const [moduledataList, SetmoduledataList] = useState([]);

  const getData = () => {
    const filterData = {
      api_token: apiToken,
    };
    POST(moduleUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          
          SetmoduledataList(data.data);
          
        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });
  };

  const ModuleEditData = (edit_id, type) => {
    SetEditId(edit_id);
    if (type === "module") setAddModuleShow(true);
  };

  const RefreshList = () => {
    // filterItem("refresh", "", "");
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  const editFunction = (editId) => {
    SetsubEditData(editId);
    setEditModalShow(true);
  };


  const editFun = (editId) => {
    SeteditSubmodule(true);
    SetsubEditData(editId);
  };

  const handleModalClose = () => setAddModuleShow(false);
  const handleModalShow = () => setAddModuleShow(true);

  const handleSubModuleModalClose = () => SetSubAddModuleShow(false);
  const handleSubModuleModalShow = () => SetSubAddModuleShow(true);

  const StatusChnageFun = (edit_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      type: type,
    };
    POST(moduleChangeStatusUrl, editData)
      .then((response) => {
        const { message, data } = response.data;
      
        getData();

        // RefreshList();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };
  const SectionSourceChangeFun = (e,edit_id) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      section_source: e.target.value,
    };
    POST(moduleSectionSourceUrl, editData)
      .then((response) => {
        const { message, data } = response.data;
        // update side module and section
        // dispatch(updateModuleListState(data));
        getData();
        // RefreshList();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  const SortOrderUpdate = (e, edit_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      sort_order: e.target.value,
      type: type,
    };
    POST(moduleUpdateSortOrderUrl, editData)
      .then((response) => {
        const { message, data } = response.data;

        // update side module and section
        // dispatch(updateModuleListState(data));
        getData();
        // RefreshList();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  useEffect(() => {
    let abortController = new AbortController();
    SetmoduledataList(dataList);
    return () => abortController.abort();
  }, [dataList]);

  const LiveStatusChangeFun = (edit_id, type) => {
    const editData = {
      api_token: apiToken,
      update_id: edit_id,
      type: type,
      completion_status: "completion_status",
    };
    POST(moduleChangeStatusUrl, editData)
      .then((response) => {
        const { message, data } = response.data;
        // update side module and section
        // dispatch(updateModuleListState(data));
        getData();
        // RefreshList();
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

  return (
    <>
      {/* <ColorInfo /> */}
      <div className="row">
        <div className="col-lg-12 mx-auto">
          <div className="media-body">
            <div className="card ">
              <div className="card-body ">
                <div className="table-responsive">
                  <table className="table mb-4">
                    <thead>
                      <tr>
                        <th style={{ width: "200px" }}>Section</th>
                        <th style={{ width: "200px" }} className="text-center">
                          URL
                        </th>
                        <th  style={{ width: "200px" }} className="text-center">{Trans("SECTION_SOURCE", language)}</th>
                        <th style={{ width: "150px" }} className="text-center">
                          Sort Order
                        </th>
                        <th style={{ width: "150px" }} className="text-center">
                          Completion 
                        </th>
                        <th style={{ width: "150px" }} className="text-center">
                          Live Status
                        </th>
                        <CheckPermission
                          PageAccess={PageModule}
                          PageAction={PreUpdate}>
                        <th style={{ width: "150px" }} className="text-center">
                          Action{" "}
                        </th>
                        </CheckPermission>
                      </tr>
                    </thead>
                  </table>
                  {moduledataList != null &&
                    moduledataList.map((modaldata, index) => {
                      const {
                        module_id,
                        module_name,
                        status,
                        access_priviledge,
                        completion_status,
                        sort_order,
                        quick_access,
                      } = modaldata;
                      return (
                        <>
                          <table className="table mb-4">
                            <thead>
                              <tr>
                                <th style={{ width: "200px" }}>
                                {Trans(module_name, language)}            
                                </th>
                                <th
                                  style={{ width: "200px" }}
                                  className="text-center"
                                >
                                  {access_priviledge == "0"
                                    ? "Super Admin"
                                    : access_priviledge == "1"
                                    ? "All"
                                    : "Subscriber"}
                                </th>

                                <th
                                  style={{ width: "200px" }}
                                  className="text-center"
                                >
                                 
                                </th>

                                <th
                                  style={{ width: "150px" }}
                                  className="text-center"
                                >
                                  <input
                                    type="number"
                                    style={{ width: 50 }}
                                    defaultValue={sort_order}
                                    onBlur={(e) => {
                                      SortOrderUpdate(e, module_id, "module");
                                      // filterItem("refresh", "", "");
                                    }}
                                  />
                                </th>
                                <th
                                  style={{ width: "150px" }}
                                  className="text-center"
                                >
                                  <div className="custom-control custom-switch">
                                    <input
                                      onClick={() => {
                                        LiveStatusChangeFun(
                                          module_id,
                                          "module"
                                        );
                                        // filterItem("refresh", "", "");
                                      }}
                                      type="checkbox"
                                      class="custom-control-input"
                                      id={`LiveStatusChangeFun${module_id}module`}
                                      checked={
                                        modaldata.completion_status === 0
                                          ? ""
                                          : "checked"
                                      }
                                    />
                                    <label
                                      className="custom-control-label"
                                      For={`LiveStatusChangeFun${module_id}module`}
                                    ></label>
                                  </div>
                                </th>

                                <th
                                  style={{ width: "150px" }}
                                  className="text-center"
                                >
                              
                                  <div className="custom-control custom-switch">
                                    <input
                                      onClick={() => {
                                        StatusChnageFun(module_id, "module");
                                        // filterItem("refresh", "", "");
                                      }}
                                      type="checkbox"
                                      class="custom-control-input"
                                      id={`customSwitch${module_id}module`}
                                      checked={status === 0 ? "" : "checked"}
                                    />
                                    <label
                                      className="custom-control-label"
                                      For={`customSwitch${module_id}module`}
                                    ></label>
                                  </div>
                                </th>

                                <CheckPermission
                                                        PageAccess={PageModule}
                                                        PageAction={PreUpdate}>
                                <th
                                  style={{ width: "150px" }}
                                  className="text-center"
                                >
                                   
                                  <button
                                    type="button"
                                    class="btn btn-primary btn-xs btn-icon"
                                    onClick={() => {
                                      ModuleEditData(module_id, "module");
                                    }}
                                  >
                                    <svg
                                      width="20"
                                      height="20"
                                      viewBox="0 0 24 24"
                                      fill="white"
                                      stroke="currentColor"
                                      stroke-width="2"
                                      stroke-linecap="round"
                                      stroke-linejoin="round"
                                      class="feather feather-edit-2 "
                                    >
                                      <g>
                                        <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                      </g>
                                    </svg>
                                  </button>
                                
                                  {/* <span title="Edit">
                                    <FeatherIcon
                                      style={{ cursor: "pointer" }}
                                      icon="edit"
                                      size={20}
                                    
                                    />
                                  </span> */}
                                </th>
                                </CheckPermission>
                              </tr>
                            </thead>
                            <tbody>
                              {modaldata?.section_list &&
                                modaldata?.section_list.map(
                                  (nesteddata, index) => {
                                    return nesteddata?.sub_section.length >
                                      1 ? (
                                      <>
                                        <tr>
                                          <th>
                                            <FeatherIcon
                                              style={{
                                                cursor: "pointer",
                                              }}
                                              icon="chevron-down"
                                              size={20}
                                            />
                                              {Trans(nesteddata.section_name, language)}  
                                            {/* {nesteddata.section_name} */}
                                          </th>
                                          <th
                                            style={{ paddingLeft: "1.4rem" }}
                                            className="text-center"
                                          >
                                            {nesteddata.section_url}
                                          </th>

                                          <th
                                            style={{ paddingLeft: "1.4rem" }}
                                            className="text-center"
                                          >
                                            <select
                                                      defaultValue={nesteddata.section_source}
                                                      onBlur={(e) => {
                                                        SectionSourceChangeFun(
                                                          e,
                                                          nesteddata.section_id,
                                                          
                                                        );
                                                        }}
                                                      className="form-control">
                            
                                          <option value="1">
                                          {Trans("App", language)}
                                          </option>
                                          <option value="2">
                                          {Trans("Dashboard", language)}
                                          </option>
                                 
                              </select>
                                          </th>

                                          <th className="text-center">
                                            <input
                                              type="number"
                                              style={{ width: 50 }}
                                              defaultValue={
                                                nesteddata.sort_order
                                              }
                                              onBlur={(e) => {
                                                SortOrderUpdate(
                                                  e,
                                                  nesteddata.section_id,
                                                  "section"
                                                );
                                                // filterItem("refresh", "", "");
                                              }}
                                            />
                                          </th>
                                          <th className="text-center">
                                            <div className="custom-control custom-switch">
                                              <input
                                                onClick={() => {
                                                  LiveStatusChangeFun(
                                                    nesteddata.section_id,
                                                    "section"
                                                  );
                                                  // filterItem("refresh", "", "");
                                                }}
                                                type="checkbox"
                                                class="custom-control-input"
                                                id={`LiveStatusChangeFun${nesteddata.section_id}section_id`}
                                                checked={
                                                  nesteddata.completion_status ===
                                                  0
                                                    ? ""
                                                    : "checked"
                                                }
                                              />
                                              <label
                                                className="custom-control-label"
                                                For={`LiveStatusChangeFun${nesteddata.section_id}section_id`}
                                              ></label>
                                            </div>
                                          </th>
                                          <th className="text-center">
                                            <div className="custom-control custom-switch">
                                              <input
                                                onClick={() => {
                                                  StatusChnageFun(
                                                    nesteddata.section_id,
                                                    "section"
                                                  );
                                                  // filterItem("refresh", "", "");
                                                }}
                                                type="checkbox"
                                                class="custom-control-input"
                                                id={`chevron-downcustomSwitch${nesteddata.module_id}module_id`}
                                                checked={
                                                  nesteddata.status === 0
                                                    ? ""
                                                    : "checked"
                                                }
                                              />
                                              <label
                                                className="custom-control-label"
                                                For={`chevron-downcustomSwitch${nesteddata.module_id}module_id`}
                                              ></label>
                                            </div>
                                          </th>
                                          <CheckPermission
                                                        PageAccess={PageModule}
                                                        PageAction={PreUpdate}>

                                          <th className="text-center">
                                            {/* <span title="Edit">
                                                <FeatherIcon
                                                  style={{ cursor: "pointer" }}
                                                  onClick={() => {
                                                    editFun(
                                                      nesteddata.section_id
                                                    );
                                                  }}
                                                  icon="edit"
                                                  size={20}
                                                />
                                                {"  "}
                                              </span> */}
                                                
                                            <button
                                              type="button"
                                              class="btn btn-primary btn-xs btn-icon"
                                              onClick={() => {
                                                editFunction(nesteddata.section_id);
                                              }}
                                            >
                                              <svg
                                                width="20"
                                                height="20"
                                                viewBox="0 0 24 24"
                                                fill="white"
                                                stroke="currentColor"
                                                stroke-width="2"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                class="feather feather-edit-2 "
                                              >
                                                <g>
                                                  <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                                </g>
                                              </svg>
                                            </button>
                                           
                                          </th>
                                          </CheckPermission>
                                        </tr>

                                        {nesteddata?.sub_section.map(
                                          (sub, ind) => {
                                            return (
                                              <tr className="sun">
                                                <td>
                   
                                                  {" "}
                                                  <FeatherIcon
                                                    style={{
                                                      cursor: "pointer",
                                                    }}
                                                    icon="arrow-right"
                                                    size={20}
                                                  />
                                                  {Trans(sub.section_name, language)} 
                                                  {/* {sub.section_name} */}
                                                </td>
                                                <td
                                                  style={{
                                                    paddingLeft: "1.4rem",
                                                  }}
                                                  className="text-center"
                                                >
                                                  {sub.section_url}
                                                </td>
                                                <td
                                                  style={{
                                                    paddingLeft: "1.4rem",
                                                  }}
                                                  className="text-center"
                                                >
                                                   <select
                                                      defaultValue={sub.section_source}
                                                      onBlur={(e) => {
                                                        SectionSourceChangeFun(
                                                          e,
                                                          sub.section_id,
                                                          
                                                        );
                                                        }}
                                                      className="form-control">
                            
                                          <option value="1">
                                          {Trans("App", language)}
                                          </option>
                                          <option value="2">
                                          {Trans("Dashboard", language)}
                                          </option>
                                 
                              </select>
                           </td>


                                              
                                                <td className="text-center">
                                                  <input
                                                    type="number"
                                                    style={{ width: 50 }}
                                                    defaultValue={
                                                      sub.sort_order
                                                    }
                                                    onBlur={(e) => {
                                                      SortOrderUpdate(
                                                        e,
                                                        sub.section_id,
                                                        "section"
                                                      );
                                                    }}
                                                  />
                                                </td>

                                                <td className="text-center">
                                                  <div className="custom-control custom-switch">
                                                    <input
                                                      onChange={() => {
                                                        LiveStatusChangeFun(
                                                          sub.section_id,
                                                          "section"
                                                        );
                                                        // filterItem("refresh", "", "");
                                                      }}
                                                      type="checkbox"
                                                      class="custom-control-input"
                                                      id={`arrow-rightLiveStatusChangeFun${sub.section_id}section`}
                                                      checked={
                                                        sub.completion_status ===
                                                        0
                                                          ? ""
                                                          : "checked"
                                                      }
                                                    />
                                                    <label
                                                      className="custom-control-label"
                                                      For={`arrow-rightLiveStatusChangeFun${sub.section_id}section`}
                                                    ></label>
                                                  </div>
                                                </td>

                                                <td className="text-center">
                                                  <div className="custom-control custom-switch">
                                                    <input
                                                      onClick={() => {
                                                        StatusChnageFun(
                                                          sub.section_id,
                                                          "section"
                                                        );
                                                      }}
                                                      type="checkbox"
                                                      class="custom-control-input"
                                                      id={`arrow-rightcustomSwitch${sub.section_id}section`}
                                                      checked={
                                                        sub.status === 0
                                                          ? ""
                                                          : "checked"
                                                      }
                                                    />
                                                    <label
                                                      className="custom-control-label"
                                                      For={`arrow-rightcustomSwitch${sub.section_id}section`}
                                                    ></label>
                                                  </div>
                                                </td>
                                                <CheckPermission
                                                        PageAccess={PageModule}
                                                        PageAction={PreUpdate}>
                                                <td className="text-center">
                                               
                                                <button
                                                    type="button"
                                                    class="btn btn-primary btn-xs btn-icon"
                                                    onClick={() => {
                                                      editFunction(
                                                        sub.parent_section_id
                                                      );
                                                    }}
                                                  >
                                                    <svg
                                                      width="20"
                                                      height="20"
                                                      viewBox="0 0 24 24"
                                                      fill="white"
                                                      stroke="currentColor"
                                                      stroke-width="2"
                                                      stroke-linecap="round"
                                                      stroke-linejoin="round"
                                                      class="feather feather-edit-2 "
                                                    >
                                                      <g>
                                                        <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                                      </g>
                                                    </svg>
                                                  </button>
                                                
                                                </td>
                                                </CheckPermission>
                                              </tr>
                                            );
                                          }
                                        )}
                                      </>
                                    ) : (
                                      <tr>
                                        <td> 
                                        {Trans(nesteddata.section_name, language)} 
                                        {/* {nesteddata.section_name} */}
                                        </td>
                                        <td
                                          style={{ paddingLeft: "1.4rem" }}
                                          className="text-center"
                                        >
                                          {nesteddata.section_url}
                                        </td>

                                        <td
                                          style={{ paddingLeft: "1.4rem" }}
                                          className="text-center"
                                        >
                               <select
                                 defaultValue={nesteddata.section_source}
                                 onBlur={(e) => {
                                  SectionSourceChangeFun(
                                     e,
                                     nesteddata.section_id,
                                    
                                   );
                                  }}
                                className="form-control"
                                 
                                  >
                            
                                      <option value="1">
                                      {Trans("App", language)}
                                      </option>
                                      <option value="2">
                                      {Trans("Dashboard", language)}
                                      </option>
                                 
                              </select>
                                        </td>

                                        <td className="text-center">
                                          <input
                                            type="number"
                                            style={{ width: 50 }}
                                            defaultValue={nesteddata.sort_order}
                                            onBlur={(e) => {
                                              SortOrderUpdate(
                                                e,
                                                nesteddata.section_id,
                                                "section"
                                              );
                                              // filterItem("refresh", "", "");
                                            }}
                                          />
                                        </td>

                                        <td className="text-center">
                                          <div className="custom-control custom-switch">
                                            <input
                                              onChange={() => {
                                                LiveStatusChangeFun(
                                                  nesteddata.section_id,
                                                  "section"
                                                );
                                                // filterItem("refresh", "", "");
                                              }}
                                              type="checkbox"
                                              class="custom-control-input"
                                              id={`LiveStatusChangeFun${nesteddata.section_id}section`}
                                              checked={
                                                nesteddata.completion_status ===
                                                0
                                                  ? ""
                                                  : "checked"
                                              }
                                            />
                                            <label
                                              className="custom-control-label"
                                              For={`LiveStatusChangeFun${nesteddata.section_id}section`}
                                            ></label>
                                          </div>
                                        </td>

                                        <td className="text-center">
                                          <div className="custom-control custom-switch">
                                            <input
                                              onClick={() => {
                                                StatusChnageFun(
                                                  nesteddata.section_id,
                                                  "section"
                                                );
                                                // filterItem("refresh", "", "");
                                              }}
                                              type="checkbox"
                                              class="custom-control-input"
                                              id={`customSwitch${nesteddata.section_id}section`}
                                              checked={
                                                nesteddata.status === 0
                                                  ? ""
                                                  : "checked"
                                              }
                                            />
                                            <label
                                              className="custom-control-label"
                                              For={`customSwitch${nesteddata.section_id}section`}
                                            ></label>
                                          </div>
                                        </td>

                                        <CheckPermission
                                            PageAccess={PageModule}
                                            PageAction={PreUpdate}>
                                        <td className="text-center">
                                       
                                          <button
                                            type="button"
                                            class="btn btn-primary btn-xs btn-icon"
                                            onClick={() => {
                                              editFunction(nesteddata.section_id);
                                            }}
                                          >
                                            <svg
                                              width="20"
                                              height="20"
                                              viewBox="0 0 24 24"
                                              fill="white"
                                              stroke="currentColor"
                                              stroke-width="2"
                                              stroke-linecap="round"
                                              stroke-linejoin="round"
                                              class="feather feather-edit-2 "
                                            >
                                              <g>
                                                <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                                              </g>
                                            </svg>
                                          </button>
                                        
                                        </td>
                                        </CheckPermission>
                                      </tr>
                                    );
                                  }
                                )}
                            </tbody>
                          </table>
                        </>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Module Edit modal */}
      <Modal
        show={addModuleShow}
        onHide={() => {
          setAddModuleShow(false);
        }}
      >
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_MODULE", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              setAddModuleShow(false);
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <ModuleEdit
            editId={editId}
            RefreshList={RefreshList}
            handleModalClose={() => {
              setAddModuleShow(false);
            }}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
      {/* edit modal */}
      <Modal show={addSubModuleShow} onHide={handleSubModuleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_SECTION", language)}</Modal.Title>
          <Button variant="danger" onClick={handleSubModuleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <AddSubModule
            filterItem={filterItem}
            handleModalClose={handleSubModuleModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit submodule */}
      <Modal
        show={editSubmodule}
        onHide={() => {
          SeteditSubmodule(false);
        }}
      >
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_SUB_MODULE", language)}</Modal.Title>
          <Button
            variant="danger"
            onClick={() => {
              SeteditSubmodule(false);
            }}
          >
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <SubSectionEdit
            editId={subeditdata}

            handleModalClose={handleModalClose}
            // RefreshList={RefreshList}
            // handleModalClose={() => {
            //   setAddModuleShow(false);
            // }}
          />
        </Modal.Body>
      </Modal>




   {/* edit modal */}
   <Modal show={editModalShow} onHide={handleEditModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_SUB_MODULE", language)}</Modal.Title>
          <Button variant="danger" onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <SubSectionEdit
            editId={subeditdata}
          //  filterItem={filterItem}
            handleModalClose={handleEditModalClose}
         
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}










    </>
  );
}

export default Table;
