import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { servicePlanStoreUrl ,servicePlanCreateUrl} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  TextArea,
  StatusSelect,
  IsFeatured,
  Label,
} from "component/UIElement/UIElement";
import Select from "react-select";

import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import MyEditor from "component/MyEditor";
import { ErrorMessage } from "@hookform/error-message";

const PlanCreate = (props) => {
  const { grpId } = props;
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;

    POST(servicePlanStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [groupList, SetgrpList] = useState([]);

  const ModuleLoad = () => {
    const filterData = {
      api_token: apiToken,
    
    };

    POST(servicePlanCreateUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
            
            SetgrpList(data);

        } else Notify(false, Trans(message, language));
      })
      .catch((error) => {
        console.error("There was an error!", error);
        Notify(false, Trans(error.message, language));
      });

  };

  useEffect(() => {
    let abortController = new AbortController();
    ModuleLoad();
    return () => abortController.abort();
  }, []);

  const [MultiSelectItem, SetMultiSelectItem] = useState("");
  const handleMultiSelectChange = (newValue, actionMeta) => {
    let listArr = [];
    for (let index = 0; index < newValue.length; index++) {
      listArr[index] = newValue[index].value;
    }
    listArr = listArr.join(",");
    SetMultiSelectItem(listArr);
  };

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <Row>
        <input type="hidden" {...register("group_id")}  value={grpId}/>
      
          <Col col={12}>
            <FormGroup mb="20px">
              <Input
                id={Trans("PLAN_NAME", language)}
                label={Trans("PLAN_NAME", language)}
                placeholder={Trans("PLAN_NAME", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("plan_name", {
                  required: Trans("PLAN_NAME_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="plan_name" />
              </span>
            </FormGroup>
          </Col>

         
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("PLAN_DISCOUNT", language)}
                type="number"
                label={Trans("PLAN_DISCOUNT", language)}
                placeholder={Trans("PLAN_DISCOUNT", language)}
                className="form-control"
                {...register("plan_discount")}
              />
            </FormGroup>
          </Col>
        
          <Col col={12}>
            <FormGroup mb="20px">
              <IsFeatured
                id={Trans("IS_FEATURED", language)}
                label={Trans("IS_FEATURED", language)}
                className="form-control"
                {...register("featured", {
                  required: Trans("IS_FEATURED_REQUIRED", language),
                })}
              />
               <span className="required">
                <ErrorMessage errors={errors} name="featured" />
              </span>
            </FormGroup>
          </Col>


          <Col col={4}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("SUBMIT", language)}
              className="btn btn-primary btn-block"
            />
          </Col>
        </Row>
      </form>
    </>
  );
};

export default PlanCreate;

