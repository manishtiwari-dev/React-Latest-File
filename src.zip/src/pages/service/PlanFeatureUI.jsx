import React, { useState } from "react";
import { LoaderButton, FormGroup, Label ,Col} from "component/UIElement/UIElement";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import { useForm, FormProvider } from "react-hook-form";
import POST from "axios/post";
import { ServiceplanToFeatureStoreUrl,ServiceplanToFeatureUrl,ServicePlanFeatureSortOrderUrl,ServicePlanFeatureStatusUrl } from "config";
import Alert from "component/UIElement/Alert";
import Notify from "component/Notify";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useEffect } from "react";
import Loading from "component/Loading";
import CheckPermission from "helper";
import { useParams } from "react-router-dom";

import {
  PageServicePlanToFeature,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";
import { Modal, Button } from "react-bootstrap";
import Create from "./FeatureCreate";
import Edit from "./FeatureEdit";
import WebsiteLink from "config/WebsiteLink";
import { Anchor } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";

function PlanFeatureUI(props) {
  const { language, apiToken ,userType} = useSelector((state) => state.login);
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const { grpId } = useParams();
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");

   const methods = useForm();


   const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
   const {
     register,
     handleSubmit,
     setValue,
     formState: { errors },
   } = methods;

  const [msgType, setMsgType] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  


  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    formData.api_token = apiToken;
    POST(ServiceplanToFeatureStoreUrl, formData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
        
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              console.log(message[key][0]);
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = Trans(message, language);
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };




  const [selectType, SetSelectType] = useState(1);
  const [grpName, SetGroupName] = useState("");

  const [permissionList, setPermissionList] = useState([]);
  const [sectionList, SetSectionList] = useState([]);
  const [moduleList, SetModuleList] = useState([]);
  const [contentloadingStatus, SetloadingStatus] = useState(false);
  const [statuslist,SetStatuslist] =useState("");

   const [planList, SetplanList] = useState([]);

   const findListBanner = (id,sortBys, orderByS) => {
    const filterData = {
      api_token: apiToken,
      language:language,
      group_id: id,
      sortBy: sortBys,
      orderBY: orderByS,
      userType: userType,       
      language: language,
     
    };
    POST(ServiceplanToFeatureUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
    
        if (status) {
          SetloadingStatus(false);
          SetplanList(data.plan_data);
         SetSectionList(data.feature_list);
        SetModuleList(data.feature_list);
        SetGroupName(data.group_name);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

    useEffect(() => {
    let abortController = new AbortController();
  
    findListBanner(grpId,sortByS, orderByS);
    return () => abortController.abort();
  }, []);




  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

//   const editPlan = (feature_id) => {
//     setEditModalShow(true);
//     SetEditData(feature_id);
//   };
  const editFun = (editId) => {
    setEditModalShow(true);
    SetEditData(editId);
  };



  const [editPermission, SetEditPermission] = useState();


  const editFunction = (editId) => {
    editFun(editId);
  };


 
  var set2 = new Set();
  {
    sectionList &&
    sectionList.map((template, idx) => {
        set2.add(template.featureGroup);
      });
  }
  let arrayhead = [...set2];

  let ar1;
  let bigar = new Set();
  {
    for (let i = 0; i < arrayhead.length; i++) {
      ar1 = [];

      for (let j = 0; j < sectionList.length; j++) {
        if (sectionList[j].featureGroup == arrayhead[i]) {
          ar1.push(sectionList[j]);
        }
      }
      bigar.add(ar1);
    }
    console.log(bigar);
  }
  let arraylist = [...bigar];

  const filterItem = () => {
    findListBanner(grpId);
  };


const ChangeFunction = (quoteId) => {
    const editData = {
      api_token: apiToken,
      feature_id: quoteId,
    //  status: statusId,
    };
    POST(ServicePlanFeatureStatusUrl, editData)
      .then((response) => {
        const { message } = response.data;
        findListBanner(grpId);

        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
      
  };


const statusColor = ["danger",  "success", ];

const StatusChange = (quoteId, ) => {
    ChangeFunction(quoteId);
};


  const UpdateSortOrder = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      feature_id: update_id,
      sort_order: sortOrder,
    };
    POST(ServicePlanFeatureSortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };

 

  return (

    <Content>
   
  <CheckPermission PageAccess={PageServicePlanToFeature} PageAction={PreView}>

    <React.Fragment>
      {msgType.length > 2 &&
        (msgType === "success" ? (
          <Alert type="success">{errorMsg}</Alert>
        ) : (
          <Alert type="danger">{errorMsg}</Alert>
        ))}
      <FormProvider {...methods}>
        <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        
      
{/* 
                            <FormGroup mb="20px">
                              <Label
                                display="block"
                                mb="5px"
                                htmlFor={Trans("INDUSTRY", language)}
                              >
                                {Trans("INDUSTRY", language)}
                              </Label>
                              <select
                                {...register("industry_id", {
                                 
                                })}
                                className="form-control"
                                 onChange={(e) => getPlanListBYIndustryId(e.target.value)}

                                // onChange={(event) => {
                                //   SetSelectType(event.target.value);
                                // }}
                              
                              >
                               <option value="" >
                               {Trans("PLEASE_SELECT", language)}
                                      </option>

                                {industryList &&
                                  industryList.map((industry, idx) => {
                                    return (
                                      <option value={industry.industry_id} key={idx}>
                                        {industry.industry_name}
                                      </option>
                                    );
                                  })}
                              </select>
                            </FormGroup> */}

                            
                        
  

          <FormGroup mb="20px">
            <Label display="block" mb="5px" htmlFor="permissionList">
            <b>{grpName} {" "}{Trans("PLAN", language)}:</b>
            </Label>
            <div className="d-none d-md-flex justify-content-end mb-1">
                  <CheckPermission
                    PageAccess={PageServicePlanToFeature}
                    PageAction={PreAdd}
                  >
                    <Button variant="primary" onClick={handleModalShow}>
                      <FeatherIcon
                        icon="plus"
                        fill="white"
                     //   className="wd-10 mg-r-5"
                      />
                      {Trans("ADD_PLAN_FEATURE", language)}
                    </Button>
                  </CheckPermission>


                  <Anchor
                  className="btn btn-primary btn-xs btn-icon py-2"
                  path={WebsiteLink("/service-plan-group")}
                >
                  <FeatherIcon
                    icon="corner-down-left"
                    className="wd-10 mg-r-5"
                  />
                  {Trans("GO_BACK", language)}
                </Anchor>
                   



                </div>
            <React.Fragment>
    
        <React.Fragment>
                   
          <div className="row">
         
           
           <div className="col-md-3 plan_select">  <b>{Trans("PLAN_FEATURE_LIST", language)}</b></div>
           <div className="col-md-6 plan_select">
           <div className="row ">
           {planList &&
                  planList.map((plan, chid) => {
                    return (
                      <React.Fragment key={chid}>
                        <div className="col-md-4 border_right text-uppercase">
                          <b>{plan?.plan_name}</b>
                        </div>
                      </React.Fragment>
                    );
                  })}
            </div>
            </div>

            <div className="col-md-3 plan_select text-center">  <b>
         
         {Trans("ACTION", language)}
        </b></div>

          </div>


         <div className="row">
            
             <div className="col-md-12">

             {arrayhead &&
               arrayhead.map((head, index) => { 
              return(
                <div className="col-md-12">
                        <fieldset className="form-fieldset">
               <legend>
                          {Trans(head, language)}
                          </legend> 
                <>
                  {arraylist &&
                            arraylist.map((e, idx) => {
                              return e.map((Feature) => {
                                const {
                                feature_id,
                  
                                feature_title,
                                feature_details,
                                featureGroup,
                                featureStatus,
                                status,
                                sort_order,
                                } = Feature;
                                console.log(Feature);
                              
                                return  featureGroup == head ? (
                                  <>
                                 <div className="tx-right d-none d-md-block  d-flex align-items-center  pb-3 ">
                                  <input
                                  style={{ height: "35px" , width: "40px" ,'text-align':"left"}} 
                                    type="number"
                                    name=""
                                    id=""
                                    defaultValue={sort_order}
                                    onBlur={(e) => {
                                        UpdateSortOrder(
                                          Feature.feature_id,
                                        e.target.value
                                    );
                                    }}
                                />

                              <Button variant="primary"  onClick={() =>editFunction(Feature.feature_id)}  className="btn btn-primary btn-xs btn-icon ml-2 ">
                                <FeatherIcon
                                  icon="edit-2"
                                  fill="white"
                                  size={20}
                                  onClick={() =>editFunction(Feature.feature_id)}
                                />
                                </Button>
                               <div  className=" custom-switch  d-inline-block pl-4 ">
                                <input
                                style={{ height: "30px" , width: "50px" ,}} 
                                      onClick={() => {
                                        StatusChange(
                                          Feature.feature_id
                                        );
                                      }}
                                      type="checkbox"
                                      class="custom-control-input  custom-control custom-switch"
                                      id={`customSwitch${Feature.feature_id}`}

                                      checked={
                                        status === 0
                                          ? ""
                                          : "checked"
                                      }
                                />
                            <label
                              className="custom-control-label"
                              For={`customSwitch${Feature.feature_id}`}
                            ></label>
                           </div>
                              </div>


                             
                                  {Feature?.sub_feature &&
                                    Feature?.sub_feature.map( (parentdata, index) => {
                                      const {
                                        feature_id,
                                        feature_title,
                                        feature_details,
                                        featureGroup,
                                        featureStatus,
                                        status,
                                        sort_order,
                                        } = parentdata;
                                        console.log(parentdata);
                                        return(
                                          <>  
                                          
                                  <div className="row plan_select">
                                 
                                  <div className="col-md-2 plan_select">
                                
                                  <label className="">
                                    <h6>{parentdata.feature_title}</h6>
                                                       
                                  </label>
                         
                                    </div>  
                                      
                                <div className="col-md-7 align-items-center">
                                  <div className="row">                      
                                  {planList &&
                                    planList.map((ch, chid) => {     
                                     const {
                      
                                         features,
                                         limits,
                                         status,
                                         } = ch
                                         ;
                                         
                                        return (
                                       <>
                                          
                                          
                                    
                        <div key={chid} className="col-md-4 plan_select d-flex justify-content-between align-items-center">
            
            
                                            <select
                                              {...register(
            
                                                `status_${ch.plan_id}_${parentdata.feature_id}`
                                              )}
                                              className=""
                                              defaultValue={
                                                features[parentdata.feature_id] === undefined
                                                  ? 'no'
                                                  : features[parentdata.feature_id]
                                              }
                                            >

                                              <option >
                                                {Trans("SELECT", language)}
                                              </option>
                                              
                                      <option className="text-success" value="yes"> {Trans("yes", language)} </option>
                                      <option  className="text-danger"  value="no"> {Trans("no", language)} </option>
                                          
                                            </select>
            
                                            <FormGroup  className="mb-0">
                                                <input
                                                  id="name"
                                                  type="text"
                                                  className="form-controls"
                                                  placeholder="FEATURE_LIMIT"
                                                  defaultValue={
                                                    limits[parentdata.feature_id] === undefined
                                                      ? ''
                                                      : limits[parentdata.feature_id]
                                                  }
                                                

                                                  {...register(
                    
                                                    `feature_limit_${ch.plan_id}_${parentdata.feature_id}`
                                                  
                                                  )}
                                                
                                                />
                                              
                                              </FormGroup>
                                          </div>
                                         
                                         
                                       </>
                                       
            
                                        );
                                      })}
                   
                                  </div>
                                </div>


                                <div className="col-md-3 text-center ">
                            <div className="d-flex align-items-center justify-content-center  gap-4">
                          <input
                          style={{ height: "30px" , width: "50px" ,'text-align':"center"}} 
                            type="number"
                            name=""
                            id=""
                            defaultValue={sort_order}
                            onBlur={(e) => {
                                UpdateSortOrder(
                                  parentdata.feature_id,
                                e.target.value
                            );
                            }}
                        />
                        {" "}

                        <Button variant="primary"  onClick={() =>editFunction(parentdata.feature_id)}  className="btn btn-primary btn-xs btn-icon">
                                <FeatherIcon
                                  icon="edit-2"
                                  fill="white"
                                  size={20}
                                  onClick={() =>editFunction(parentdata.feature_id)}
                                />
                                </Button>

                                  {" "}

                        <div  className=" custom-switch pl-4 ">
                              <input
                                style={{ height: "30px" , width: "50px" ,'text-align':"center"}} 
                                      onClick={() => {
                                        StatusChange(
                                          parentdata.feature_id
                                        );
                                      }}
                                      type="checkbox"
                                      class="custom-control-input  custom-control custom-switch"
                                      id={`customSwitch${parentdata.feature_id}`}

                                      checked={
                                        status === 0
                                          ? ""
                                          : "checked"
                                      }
                                />
                            <label
                              className="custom-control-label"
                              For={`customSwitch${parentdata.feature_id}`}
                            ></label>
                              </div>
    
                            </div>
                                </div> 







                                </div> 
                            </>    );

                                    })}
                              </>  ) : (
                                  ""
                                );
                              });
                            })}


             </>
             </fieldset> </div>);
                          })}
                  
                  
                    </div>
                 
             
           
          </div>
        </React.Fragment>
      
           </React.Fragment>  
          </FormGroup>


<Col col={4}>
<LoaderButton
            formLoadStatus={formloadingStatus}
            btnName={Trans("UPDATE", language)}
            className="btn btn-primary btn-block"
          />
          </Col>
         
        </form>
      </FormProvider>
    </React.Fragment>
       </CheckPermission>



       {/* add modal */}
       <Modal show={show} onHide={handleModalClose}  size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("ADD_PLAN_FEATURE", language)}</Modal.Title>
          <Button variant="danger" onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create  handleModalClose={handleModalClose}    filterItem={filterItem} />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
  {/* edit modal */}
  <Modal show={editModalShow} onHide={handleEditModalClose} size="lg">
        <Modal.Header>
          <Modal.Title>{Trans("EDIT_PLAN_FEATURE", language)}</Modal.Title>
          <Button variant="danger" onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editData}
            filterItem={filterItem}
            handleModalClose={handleEditModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
     






    </Content>
  );
}

export default PlanFeatureUI;


