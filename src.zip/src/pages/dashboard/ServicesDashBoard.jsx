import React from "react";
import POST from "axios/post";
import Chart from "react-apexcharts";
import FeatherIcon from "feather-icons-react";

import { useSelector } from "react-redux";
import Content from "layouts/content";
import { Trans } from "lang";
import PageHeader from "component/PageHeader";
import { useState } from "react";
import { DashboardUrl } from "config/index";
import Notify from "component/Notify";
import { BadgeShow, Anchor } from "component/UIElement/UIElement";
import WebsiteLink from "config/WebsiteLink";
import { Modal, Button } from "react-bootstrap";
import EnquiryDashboardModel from "./EnquiryDashboardModel";
import CustomerDashboardModel from "./CustomerModal";
function ServiceDashboard() {
  const { role, apiToken, userType, language, industry } = useSelector(
    (state) => state.login
  );


  const [dashboardData, SetdashboardData] = useState([]);
  const [dashboardcontent, Setdashboardcontent] = useState("");
  React.useEffect(() => {
    const formData = {
      api_token: apiToken,
      language: language,
      userType: userType,
      industry_id: industry,
    };
    POST(DashboardUrl, formData)
      .then((response) => {
        const { status, data } = response.data;
        if (status) {
          SetdashboardData(data);
        } else Notify(false, Trans("HAVING_ISSUE_WITH_LANGUAGE", language));
      })
      .catch((error) => {
        Notify(false, error.message);
        console.error("There was an error!", error);
      });
  }, []);

  //   const options = {
  //     chart: {
  //       id: "basic-bar",
  //     },
  //   };

  //   const data = [
  //     {
  //       name: "series-1",
  //       data: [30, 40, 45, 50, 49, 60, 70, 91],
  //     },
  //   ];
  const state = {
    options: {},
    series: [44, 55, 41, 17, 15],
    labels: ["A", "B", "C", "D", "E"],
  };

  const plan_states = {
    series: [
      {
        name: "PLAN A",
        data: [44, 55, 41, 67, 22, 43],
      },
      {
        name: "PLAN B",
        data: [13, 23, 20, 8, 13, 27],
      },
      {
        name: "PLAN C",
        data: [11, 17, 15, 15, 21, 14],
      },
      {
        name: "PLAN D",
        data: [21, 7, 25, 13, 22, 8],
      },
    ],
    options: {
      chart: {
        type: "bar",
        height: 300,
        stacked: true,
        toolbar: {
          show: true,
        },
        zoom: {
          enabled: true,
        },
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            legend: {
              position: "bottom",
              offsetX: -10,
              offsetY: 0,
            },
          },
        },
      ],
      plotOptions: {
        bar: {
          horizontal: false,
          borderRadius: 10,
        },
      },
      xaxis: {
        type: "datetime",
        categories: [
          "01/01/2011 GMT",
          "01/02/2011 GMT",
          "01/03/2011 GMT",
          "01/04/2011 GMT",
          "01/05/2011 GMT",
          "01/06/2011 GMT",
        ],
      },
      legend: {
        position: "right",
        offsetY: 40,
      },
      fill: {
        opacity: 1,
      },
    },
  };
  // transacationmodal
  const [showenquiryModal, SetshowenquiryModal] = useState(false);
  const handleshowenquiryModal = () => {
    SetshowenquiryModal(showenquiryModal ? false : true);
  };

  const [showticketModal, SetshowticketModal] = useState(false);
  const handleshowticketModal = () => {
    SetshowticketModal(showticketModal ? false : true);
  };

  const [showcustomerModal, SetshowcustomerModal] = useState(false);
  const handleShowcustomerModal = () => {
    SetshowcustomerModal(showcustomerModal ? false : true);
  };
  return (
    <React.Fragment>
      <Content>
        <div className="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
          <div>
          
            <h4 className="mg-b-0 tx-spacing--1">Welcome to Dashboard</h4>
          </div>
          <div className="d-none d-md-block">
            <Anchor
              path={WebsiteLink("/products/create")}
              className="btn btn-sm pd-x-15 btn-primary  mg-l-5"
            >
              <FeatherIcon icon="plus" fill="white" className="wd-10 mg-r-5" />
              {Trans("ADD_LISTING", language)}
            </Anchor>
            {"   "} {"  "} &nbsp;
          </div>
        </div>

        <div className="row row-xs">
          <div className="col-sm-6 col-lg-2">
            <div className="card card-body">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("TOTAL_SUBSCRIBER", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.total_subscription}
                </h3>
              </div>
            </div>
          </div>

          <div className="col-sm-6 col-lg-2">
            <div className="card card-body">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("TOTAL_USERS", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.total_users}
                </h3>
              </div>
            </div>
          </div>
          <div className="col-sm-6 col-lg-2">
            <div className="card card-body">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("NUMBER_OF_CATEGORY", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.no_of_categories}
                </h3>
              </div>
            </div>
          </div>

          <div className="col-sm-6 col-lg-2">
            <div className="card card-body">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("NUMBER_OF_PRODUCT", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.no_of_listing}
                </h3>
              </div>
            </div>
          </div>
          <div className="col-sm-6 col-lg-2">
            <div className="card card-body">
              <h6 className=" tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("NUMBER_OF_REVIEWS", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.no_of_reviews}
                </h3>
              </div>
            </div>
          </div>
          {/* <div className="col-sm-6 col-lg-2">
            <div className="card card-body">
              <h6 className="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold mg-b-8">
                {Trans("NUMBER OF REVIEWS", language)}
              </h6>
              <div className="d-flex d-lg-block d-xl-flex align-items-end">
                <h3 className="tx-normal tx-rubik mg-b-0 mg-r-5 lh-1">
                  {dashboardData?.No_of_reviews}
                </h3>
              </div>
            </div>
          </div> */}

          <div className="col-lg-6 col-xl-6 mg-t-10">
            <div className="card">
              <div className="card-header pd-t-20 pd-b-0 bd-b-0">
                <h6 className="mg-b-5">
                  {Trans("ORDERS_STATISTICS", language)}
                </h6>
                <p className="tx-12 tx-color-03 mg-b-0">
                  {Trans("LAST_12_MONTHS_ORDERS_STATISTICS", language)}
                </p>
              </div>
              <div className="card-body pd-0">
                <div className="chart-two mg-b-20">
                  <div id="className2" className="flot-chart">
                    {dashboardData?.chartItem10Year?.series && (
                      <Chart
                        options={dashboardData.chartItem10Year.options}
                        series={dashboardData.chartItem10Year.series}
                        type="bar"
                        width="98%"
                        height="225px"
                      />
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-6 col-xl-6 mg-t-10">
            <div className="card">
              <div className="card-header pd-t-20 pd-b-0 bd-b-0">
                <h6 className="mg-b-5">{Trans("PLAN_PURCHASES", language)}</h6>
                <p className="tx-12 tx-color-03 mg-b-0">
                  {Trans("LAST_12_MONTHS_ORDERS_STATISTICS", language)}
                </p>
              </div>
              <div className="card-body pd-0">
                <div className="chart-two mg-b-20">
                  <div id="" className="">
                    <Chart
                      options={plan_states.options}
                      series={plan_states.series}
                      type="bar"
                      height="225px"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-6 col-xl-4 mg-t-10">
            <div className="card ht-100p">
              <div className="card-header d-flex align-items-center justify-content-between">
                <h6 className="mg-b-0">Plan Purchase</h6>
              </div>

              {dashboardData?.plan_list && (
                <ul className="list-group list-group-flush tx-13">
                  {dashboardData?.plan_list.map((plan, indx) => {
                    // const {
                    //   No_of_categories,
                    //   No_of_products,
                    //   No_of_reviews,
                    //   total_customer_list,
                    //   total_enquiry_list,
                    //   total_order_list,
                    //   total_quatations,
                    //   total_users,
                    // } = plan;
                    return (
                      <li className="list-group-item d-flex pd-sm-x-20">
                        <div className="avatar">
                          <span className="avatar-initial rounded-circle bg-gray-600">
                            {/* {customer.first_name.charAt(0)} */}
                            {plan.plan_id}
                          </span>
                        </div>
                        <div className="pd-l-10">
                          <p className="tx-medium mg-b-0">{plan.plan_name}</p>
                          <small className="tx-12 tx-color-03 mg-b-0">
                            #{plan.plan_desc}
                          </small>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
              <div className="card-footer text-center tx-13">
                {/* <a href="" className="link-03">
                  {" "}
                  <i className="icon ion-md-arrow-down mg-l-5"></i>
                </a> */}
                <Anchor path={WebsiteLink("/superadmin/plan")} className="link-03">
                  <i className="icon ion-md-arrow-down mg-l-5">
                    {Trans("VIEW_MORE_PLAN", language)}
                  </i>
                </Anchor>
              </div>
            </div>
          </div>

          <div className="col-md-6 col-xl-4 mg-t-10">
            <div className="card ht-100p">
              <div className="card-header d-flex align-items-center justify-content-between">
                <h6 className="mg-b-0">New Customers</h6>
              </div>

              {dashboardData?.total_customer_list && (
                <ul className="list-group list-group-flush tx-13">
                  {dashboardData?.total_customer_list.map((customer, indx) => {
                    const {
                      No_of_categories,
                      No_of_products,
                      No_of_reviews,
                      total_customer_list,
                      total_enquiry_list,
                      total_order_list,
                      total_quatations,
                      total_users,
                    } = customer;
                    return (
                      <li className="list-group-item d-flex pd-sm-x-20">
                        <div className="avatar">
                          <span className="avatar-initial rounded-circle bg-gray-600">
                            {/* {customer.first_name.charAt(0)} */}
                            {customer.customer_id}
                          </span>
                        </div>
                        <div className="pd-l-10">
                          <p className="tx-medium mg-b-0">
                            {customer.first_name} {customer.last_name}
                          </p>
                          <small className="tx-12 tx-color-03 mg-b-0">
                            Customer ID#{customer.customer_id}
                          </small>
                        </div>
                        <div className="mg-l-auto text-right">
                          {/* <p className="tx-medium mg-b-0">+ $250.00</p> */}
                          <small
                            style={{ cursor: "pointer" }}
                            className="tx-12 tx-success mg-b-0"
                            onClick={() => {
                              Setdashboardcontent(JSON.stringify(customer));
                              handleshowticketModal();
                            
                            }}
                          >
                            Quick View
                          </small>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
              <div className="card-footer text-center tx-13">
                {/* <a href="" className="link-03">
                  {" "}
                  <i className="icon ion-md-arrow-down mg-l-5"></i>
                </a> */}
                <Anchor path={WebsiteLink("/customers")} className="link-03">
                  <i className="icon ion-md-arrow-down mg-l-5">
                    {Trans("  View More Customers", language)}
                  </i>
                </Anchor>
              </div>
            </div>
          </div>
          <div className="col-md-6 col-xl-4 mg-t-10">
            <div className="card ht-100p">
              <div className="card-header d-flex align-items-center justify-content-between">
                <h6 className="mg-b-0">Recent Enquiry</h6>
              </div>

              {dashboardData?.latest_enquiry_list && (
                <ul className="list-group list-group-flush tx-13">
                  {dashboardData.latest_enquiry_list.map((enquiry, indx) => {
                    const {
                      No_of_categories,
                      No_of_products,
                      No_of_reviews,
                      total_customer_list,
                      total_enquiry_list,
                      total_order_list,
                      total_quatations,
                      total_users,
                    } = enquiry;
               

                    return (
                      <li className="list-group-item d-flex pd-sm-x-20">
                        <div className="avatar d-none d-sm-block">
                          <span className="avatar-initial rounded-circle bg-teal">
                            {/* <i className="icon ion-md-checkmark"></i> */}
                            {enquiry.enquiry_id}
                          </span>
                        </div>
                        <div className="pd-sm-l-10">
                          <p className="tx-medium mg-b-0">
                            Enquiry number #{enquiry.enquiry_no}
                          </p>
                          <small className="tx-12 tx-color-03 mg-b-0">
                            {enquiry.created_at}
                          </small>
                        </div>
                        <div className="mg-l-auto text-right">
                          {/* <p className="tx-medium mg-b-0">+ $250.00</p> */}
                          <small
                            style={{ cursor: "pointer" }}
                            className="tx-12 tx-success mg-b-0"
                            onClick={() => {
                              Setdashboardcontent(JSON.stringify(enquiry));
                              handleshowenquiryModal();
                            }}
                          >
                            Quick View
                          </small>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
              <div className="card-footer text-center tx-13">
                <Anchor path={WebsiteLink("/enquiry")} className="link-03">
                  <i className="icon ion-md-arrow-down mg-l-5">
                    {Trans("VIEW_MORE_ENQUIRY", language)}
                  </i>
                </Anchor>
              </div>
            </div>
          </div>
        </div>
        {/* transactionlog */}

        {/*  */}
        <Modal show={showticketModal} onHide={handleshowticketModal} size="md">
          <Modal.Header>
            <Modal.Title>{Trans("CUSTOMER_INFORMATION", language)}</Modal.Title>
            <Button variant="danger" onClick={handleshowticketModal}>
              X
            </Button>
          </Modal.Header>
          <Modal.Body>
            <CustomerDashboardModel dashboardcontent={dashboardcontent} />
          </Modal.Body>
        </Modal>


        <Modal show={showenquiryModal} onHide={handleshowenquiryModal} size="md">
          <Modal.Header>
            <Modal.Title>{Trans("ENQUIRY_INFORMATION", language)}</Modal.Title>
            <Button variant="danger" onClick={handleshowenquiryModal}>
              X
            </Button>
          </Modal.Header>
          <Modal.Body>
            <EnquiryDashboardModel dashboardcontent={dashboardcontent} />
          </Modal.Body>
        </Modal>
      </Content>
    </React.Fragment>
  );
}

export default ServiceDashboard;
