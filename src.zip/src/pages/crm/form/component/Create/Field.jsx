import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { useFormContext } from "react-hook-form";
import { Card, Button } from "react-bootstrap";
import { useFieldArray } from "react-hook-form";
import { Trans } from "lang";
import { Row, Col, FormGroup, Label } from "component/UIElement/UIElement";
import FeatherIcon from "feather-icons-react";
import { ErrorMessage } from "@hookform/error-message";



function Field({ fieldTypeList ,onSelectLoad}) {
  const { language } = useSelector((state) => state.login);


  const methods = useFormContext();

  const {
    register,
    control,
    setValue,
    getValues,
    formState: { errors },
  } = methods;

  
  const form_field = useFieldArray({
    control,
    name: "form_field",
  });
  
  const [selectType, SetSelectType] = useState("");
  const [selectlabel, SetSelectLabel] = useState("field_name");
  const [show, setShow] = useState();


// // //console.log(selectType);
//  const selectFieldType = (index, type,field_Type ) => {
//    let fieldType = (`form_field.${index}.field_type`);
//    let  field_values=  (`form_field.${index}.field_values`);
//    if(field_Type ==="checkbox" || field_Type ==="dropdown")
//    {
      
//    }
   
   
//     console.log(field_values);


// };



// useEffect(() => {
// //  console.log(fieldTypeList);

//   if (fieldTypeList !== undefined) {
//     let field = [];
//     for (let index = 0; index < fieldTypeList.length; index++) {
//       const elem = fieldTypeList[index];
//       console.log(elem);
//       field.push({
//         field_label: elem.field_label,
//         field_name: elem.field_name,
//         field_type: elem.field_type,
//         field_values: elem.field_values,
//         field_class: elem.field_class,
//         required: elem.required,
//         field_width: elem.field_width,
//         placeholder: elem.placeholder,
//         validation_msg: elem.validation_msg,
//         sort_order: elem.sort_order,

//       });
//     }

//     form_field.replace(field);
//   }

// },[onSelectLoad] );


console.log(fieldTypeList);

  return (
    <Col col={12}>
      <Card className="mb-3">
        <Card.Header as="h6">
          {Trans("FORM_FIELD", language)}
          <span style={{ float: "right" }}>
            <button
              type="button"
              className="btn btn-xs btn-primary"
              onClick={() => {
                form_field.append({});
              }}
            >
              <FeatherIcon icon="plus" fill="white" />
              {Trans("ADD_MORE_FIELD", language)}
            </button>
          </span>
        </Card.Header>
      

        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th> {Trans("LABEL", language)}</th>
                <th>{Trans("FIELD_TYPE", language)}</th>
                 <th> {Trans("VALUES", language)}</th>
                <th>{Trans("CLASS", language)}</th>
                <th> {Trans("WIDTH", language)}</th>
                <th>{Trans("PLACEHOLDER", language)}</th>
                <th> {Trans("SORT_ORDER", language)}</th>
                <th>{Trans("REQUIRED", language)}</th>
                <th>{Trans("VALIDATION_MSG", language)}</th>
              </tr>
            </thead>
{/* 
       {form_field?.fields &&
              form_field?.fields.map((item, index) => {
      return(

          <> */}

    {fieldTypeList === undefined ? 
     <>

     {form_field?.fields && (
               
    <tbody>
    
          {form_field?.fields.map((item, index) => {
            return (
            <React.Fragment >
              <tr>
                <td>   
              <input
                {...register(`form_field.${index}.field_label`,
                
                {
                  required: Trans("FIELD_LABEL_REQUIRED", language),
                }
                
                
                )}
                className="form-control  form-control-sm"
                id={`slug-source`}
                placeholder={Trans("FIELD_LABEL", language)}
                // onKeyUp={() => {
                //   myfun();
                // }} 
              />
              <span className="required">
                <ErrorMessage
                  errors={errors}
                  name={`form_field.${index}.field_label`}
                />
              </span>
         
            </td>
            
          <td>  
       <select
      
        id={`form_field.${index}.field_type`}
        label={Trans("FIELD_TYPE", language)}
        hint="Enter text" // for bottom hint
        className="form-control form-control-sm px-1"
        {...register(`form_field.${index}.field_type`,

        {
          required: Trans("FIELD_TYPE_REQUIRED", language),
        }

        )}
        placeholder={Trans("FIELD_TYPE", language)}
      
        onChange={(event) => {
          SetSelectType(event.target.value);
        }}

        // onChange={(e) => {
        //   selectFieldType(index, "fieldType", e.target.value);
        // }}

      >
       <option value="">{Trans("SELECT", language)}</option>
       <option value="text">Text</option>
       <option value="checkbox">Checkbox</option>
       <option value="dropdown">Dropdown</option>
       <option value="file">File</option>
       <option value="radio">Radio</option>
       <option value="email">Email</option>
       <option value="textarea">Textarea</option>
       <option value="submit">Submit</option>
       </select>

        <span className="required">
                <ErrorMessage
                  errors={errors}
                  name={`form_field.${index}.field_type`}
                />
              </span></td>
        
        
         <td>
         <input
              {...register(`form_field.${index}.field_values`)}
              className="form-control form-control-sm px-1"
              id={`form_field.${index}.field_values`}
              placeholder="Multiple use comma seperate"
              readOnly={selectType === "checkbox" || selectType === "dropdown" ? false : true}

            />
         </td>
        
         <td>
         <input
              {...register(`form_field.${index}.field_class`)}
              className="form-control form-control-sm px-1"
              id={`form_field.${index}.field_values`}
              placeholder={Trans("FIELD_CLASS", language)}
            />
         </td>
         
         <td>
         <select
        id="FIELD_WIDTH"
        label={Trans("FIELD_WIDTH", language)}
        hint="Enter text" // for bottom hint
        className="form-control form-control-sm px-1"
        {...register(`form_field.${index}.field_width`,
        
        {
          required: Trans("field_width_REQUIRED", language),
        }
        
        )}
        placeholder={Trans("FIELD_WIDTH", language)}
      
      >
       <option value="">{Trans("SELECT", language)}</option>
       <option value="100">100</option>
       <option value="50">50</option>
       <option value="25">25</option>
    

     </select>
         </td>
         
         <td>
         <input
                {...register(`form_field.${index}.placeholder`)}
                className="form-control form-control-sm px-1"
                id={`form_field.${index}.placeholder`}
                placeholder={Trans("Placeholder", language)}
              />
             
         </td>
          <td><input
               type="number"
                {...register(`form_field.${index}.sort_order`)}
                className="form-control  form-control-sm"
                id={`form_field.${index}.sort_order`}
                placeholder={Trans("SORT_ORDER", language)}
              /></td>
       <td>      
        
      <select
        id="REQUIRED"
        label={Trans("REQUIRED", language)}
        hint="Enter text" // for bottom hint
        className="form-control form-control-sm"
        {...register(`form_field.${index}.required`)}
        placeholder={Trans("REQUIRED", language)}
         defaultValue={0}
      >
       <option value="">{Trans("SELECT", language)}</option>
       <option value="1">Yes</option>
       <option value="0">No</option>
     </select></td>
     <td>
         <input
                {...register(`form_field.${index}.validation_msg`)}
                className="form-control form-control-sm px-1"
                id={`form_field.${index}.validation_msg`}
                placeholder={Trans("VALIDATION_MSG", language)}
              />
             
         </td>

                           
     <td>  
      <Col col={1} className="px-1">
            <span style={{ lineHeight: "42px" }}>
              <FeatherIcon
                icon="x-square"
                color="red"
                onClick={() => form_field.remove(index)}
                size={20}
              />
            </span>
          </Col>
          </td>
              </tr>
            </React.Fragment>
           );
          })}
    </tbody>
      )}
      </>
     :
     (
      <>

      {fieldTypeList &&
        fieldTypeList.map((filed,idx) => {
          const { field_label, validation_msg,field_type,field_values,field_class,field_width,placeholder,required,sort_order ,editable} = filed;
         
         return(
        
          <tbody>
                  <React.Fragment >
                    <tr>
                      <td>   
                      <input
                       {...register(`form_field.${idx}.field_label`,
                      
                      {
                        required: Trans("FIELD_LABEL_REQUIRED", language),
                      }
                      
                      
                       )}
                      className="form-control  form-control-sm"
                      id={`slug-source`}
                      placeholder={Trans("FIELD_LABEL", language)}
                      // onKeyUp={() => {
                      //   myfun();
                      // }} 

                     //value={`form_field.2.${field_label}`}
                      defaultValue={field_label}
                    />
                    <span className="required">
                      <ErrorMessage
                        errors={errors}
                        name={`form_field.${idx}.field_label`}
                      />
                    </span>
               
                     </td>
                  
                 <td>  
             <select
            
              id={`form_field.${idx}.field_type`}
              label={Trans("FIELD_TYPE", language)}
              hint="Enter text" // for bottom hint
              className="form-control form-control-sm px-1"
              {...register(`form_field.${idx}.field_type`,

              {
                required: Trans("FIELD_TYPE_REQUIRED", language),
              }
      
              )}
              placeholder={Trans("FIELD_TYPE", language)}
            
              onChange={(event) => {
                SetSelectType(event.target.value);
              }}

              // onChange={(e) => {
              //   selectFieldType(index, "fieldType", e.target.value);
              // }}
              defaultValue={field_type}

            >
             <option value="">{Trans("SELECT", language)}</option>
             <option value="text">Text</option>
             <option value="checkbox">Checkbox</option>
             <option value="dropdown">Dropdown</option>
             <option value="file">File</option>
             <option value="radio">Radio</option>
             <option value="email">Email</option>
             <option value="textarea">Textarea</option>
             <option value="submit">Submit</option>
             </select>

              <span className="required">
                      <ErrorMessage
                        errors={errors}
                        name={`form_field.${idx}.field_type`}
                      />
                    </span></td> 
          
               <td>
               <input
                    {...register(`form_field.${idx}.field_values`)}
                    className="form-control form-control-sm px-1"
                    id={`form_field.${idx}.field_values`}
                    placeholder="Multiple use comma seperate"
                    readOnly={selectType === "checkbox" || selectType === "dropdown" ? false : true}
                    defaultValue={field_values}
                  />
               </td>
              
               <td>
               <input
                    {...register(`form_field.${idx}.field_class`)}
                    className="form-control form-control-sm px-1"
                    id={`form_field.${idx}.field_values`}
                    placeholder={Trans("FIELD_CLASS", language)}
                    defaultValue={field_class}
                  />
               </td>
               
               <td>
               <select
              id="FIELD_WIDTH"
              label={Trans("FIELD_WIDTH", language)}
              hint="Enter text" // for bottom hint
              className="form-control form-control-sm px-1"
              {...register(`form_field.${idx}.field_width`,
              
              {
                required: Trans("field_width_REQUIRED", language),
              }
              
              )}
              placeholder={Trans("FIELD_WIDTH", language)}
              defaultValue={field_width}
            >
             <option value="">{Trans("SELECT", language)}</option>
             <option value="100">100</option>
             <option value="50">50</option>
             <option value="25">25</option>
          

           </select>
               </td>
               
               <td>
               <input
                      {...register(`form_field.${idx}.placeholder`)}
                      className="form-control form-control-sm px-1"
                      id={`form_field.${idx}.placeholder`}
                      placeholder={Trans("Placeholder", language)}
                      defaultValue={placeholder}
                    />
                   
               </td>

                <td><input
                     type="number"
                      {...register(`form_field.${idx}.sort_order`)}
                      className="form-control  form-control-sm"
                      id={`form_field.${idx}.sort_order`}
                      placeholder={Trans("SORT_ORDER", language)}
                      defaultValue={sort_order}
                    /></td>

                      <td>        <select
              id="REQUIRED"
              label={Trans("REQUIRED", language)}
              hint="Enter text" // for bottom hint
              className="form-control form-control-sm"
              {...register(`form_field.${idx}.required`)}
              placeholder={Trans("REQUIRED", language)}
              defaultValue={required}
            >
             <option value="">{Trans("SELECT", language)}</option>
             <option value="1">Yes</option>
             <option value="0">No</option>
                 </select></td>
           <td>
               <input
                      {...register(`form_field.${idx}.validation_msg`)}
                      className="form-control form-control-sm px-1"
                      id={`form_field.${idx}.validation_msg`}
                      placeholder={Trans("VALIDATION_MSG", language)}
                      defaultValue={validation_msg}
                    />
                   
               </td>

                                 
     {editable === 0 ?
           <td>
            
           </td>
           :
           <td>
           <Col col={1} className="px-1">
                 <span style={{ lineHeight: "42px" }}>
                  
                   <FeatherIcon
                     icon="x-square"
                     color="red"
                     onClick={() => form_field.remove(idx)}
                     size={20}
                   />
                 </span>
               </Col>
               </td>
           
           } 
         
              {/* <td>
           <Col col={1} className="px-1">
                 <span style={{ lineHeight: "42px" }}>
                   <FeatherIcon
                     icon="x-square"
                     color="red"
                     onClick={() => form_field.remove(idx)}
                     size={20}
                   />
                 </span>
               </Col>
                </td> */}


                    </tr>
                  </React.Fragment>
               
          </tbody>
          

        );
        })}
         
         </>  )
  
      }
          


          </table>
        </div>
      </Card>
    </Col>
  );
}

export default Field;
