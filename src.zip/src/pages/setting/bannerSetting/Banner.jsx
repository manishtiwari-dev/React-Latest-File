import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import ModalImage from "react-modal-image-responsive";

import {
  BannerListUrl,
  BannerUpdateSettingUrl,
  BannerGroupUrl,
  BannerChangeStatusUrl,
  BannerSortOrderUrl,
  BannerDestroyUrl,
} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Create from "./Create";
import SearchBox from "component/SearchBox";
import RecordPerPage from "component/RecordPerPage";
import { Col, BadgeShow, IconButton } from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";
import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";
import { useParams } from "react-router-dom";
import Pagination from "component/pagination/index";

import {
  BannerSetting,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";
import Table from "./component/Table";
import Edit from "./Edit";
import WebsiteLink from "config/WebsiteLink";
import { bannerSetting } from "config/WebsiteUrl";

function Banner() {
  const { bannerGroupId } = useParams();

  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");
  const [Pagi, SetPagi] = useState(0);
  const [currPage, SetcurrPage] = useState(0);
  const [searchItem, SetSEarchItem] = useState("");
  const [perPageItem, SetPerPageItem] = useState(10);

  const showColumn = [
    { label: Trans("SL_NO", language), field: "pages_id", sort: true },
    {
      label: Trans("CATEGORY_IMAGE", language),
      field: "categories_image",
      sort: true,
      field_type: "image",
    },
    {
      label: Trans("CATEGORY_NAME", language),
      field: "category_name",
      sort: false,
    },
    { label: Trans("STATUS", language), field: "status", sort: false },
    {
      label: Trans("ACTION", language),
      field: "action",
      action_list: ["edit_fun", "changeStatus"],
      sort: false,
    },
  ];

  const methods = useForm({
    defaultValues: {
      settingdata: [
        {
          banner_setting_id: 1,
          template_id: 1,
          refrence_id: "asdsad",
          banner_position_id: "",
          images_id: "",
          comment: 1,
        },
      ],
    },
  });



  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  // handle change group name
  const [sectionListing, SetSectionListing] = useState([]);

  const [bannerList, SetBannerList] = useState([]);
  const [banGrpInfo, SetbanGrpInfo] = useState([]);

  const findListBanner = (pagev, perPageItemv, searchData, sortBys, OrderBy) => {
    const filterData = {
      api_token: apiToken,
   //   banners_group_id: id,
      sortBy: sortBys,
      orderBY: OrderBy,
      page: pagev,
      perPage: perPageItemv,
      search: searchData,



    };
    POST(BannerListUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetBannerList(data.data_list);
          SetbanGrpInfo(data.info);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };
  useEffect(() => {
    
    document.title = "Banner Setting | WorkerMan";
    let abortController = new AbortController();
  //  loadSettingData();
 //   findListBanner(bannerGroupId);
    findListBanner(1, perPageItem, searchItem, sortByS, orderByS);

    return () => abortController.abort();
  }, []);




  const destroyItem = (id) => {
    const filterData = {
      api_token: apiToken,
      banners_id: id,
    };
    POST(BannerDestroyUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(bannerGroupId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const changeStatus = (id) => {
    const filterData = {
      api_token: apiToken,
      banners_id: id,
    };
    POST(BannerChangeStatusUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        findListBanner(bannerGroupId);
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  const [viewModalShow, setViewModalShow] = useState(false);
  const handleViewModalClose = () => setViewModalShow(false);

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  // const filterItem = () => {
  //   findListBanner(bannerGroupId);
  // };

  const viewFunction = (updateId) => {
    SetEditData(updateId);
    setViewModalShow(true);
  };

  const viewFun = (editId) => {
    viewFunction(editId);
  };

  const UpdateOrderStatus = (update_id, sortOrder) => {
    const editData = {
      api_token: apiToken,
      banners_id:update_id,
      sort_order: sortOrder,
    };
    POST(BannerSortOrderUrl, editData)
      .then((response) => {
        const { message } = response.data;
        Notify(true, Trans(message, language));
      })
      .catch((error) => {
      });
  };


  const filterItem = (name, value, other) => {
    switch (name) {
      case "perpage":
        SetloadingStatus(true);
        const per = Number(value);
        SetPerPageItem(per);
        findListBanner(1, per, searchItem, sortByS, orderByS);
        break;
      case "searchbox":
        SetSEarchItem(value);
        findListBanner(1, perPageItem, value, sortByS, orderByS);
        break;
      case "sortby":
        SetOrderByS(other);
        SetsortByS(value);
        findListBanner(1, perPageItem, searchItem, value, other);
        break;
      case "pagi":
        SetcurrPage(value);
        findListBanner(value, perPageItem, searchItem, sortByS, orderByS);
        break;
      default:
        findListBanner(currPage, perPageItem, searchItem, sortByS, orderByS);
        break;
    }
  };



  return (
    <Content>
      <CheckPermission PageAccess={BannerSetting} PageAction={PreView}>
        <>
         

   <div className="row row-xs">
        <div className="col-sm-12 col-lg-12">
          <CheckPermission PageAccess={BannerSetting} PageAction={PreView}>
            <div className="card" id="custom-user-list">
              <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                <h6 className="tx-semibold mg-b-0">
                  {Trans("BANNER_LIST", language)}
                </h6>
                <div className="d-none d-md-flex">
                  <CheckPermission
                    PageAccess={BannerSetting}
                    PageAction={PreAdd}
                  >
                     <Button variant="primary" onClick={handleModalShow}>
                        <FeatherIcon
                          icon="plus"
                          fill="white"
                          className="wd-10 mg-r-5"
                        />
                   {Trans("ADD_BANNER", language)}
                      </Button>
                   
                  </CheckPermission>
                </div>
              </div>
              <div className="card-body">
                <div className="d-flex">
                
                <div className="">
                    <RecordPerPage
                      filterItem={filterItem}
                      perPageItem={perPageItem}
                    />
                  </div>
                  <div className="mx-3">
                    <SearchBox filterItem={filterItem} />
                  </div>
                 
                </div>
                {contentloadingStatus ? (
                  <Loading />
                ) : (
                  <div className="row">
                    <Table
                      showColumn={showColumn}
                      bannerList={bannerList}
                      pageName={BannerSetting} // for checkpermission
                      sortBy={sortByS}
                      orderBy={orderByS}
                      filterItem={filterItem}
                      editFun={editFunction}
                      deleteFun={destroyItem}
                      updateStatusFunction={changeStatus}
                      UpdateSortOrder={UpdateOrderStatus}
                      mainKey="pages_id"
                    />
                    <Pagination
                      totalPage={Pagi}
                      currPage={currPage}
                      filterItem={filterItem}
                    />
                  </div>
                )}
              </div>
            </div>
          </CheckPermission>
        </div>
      </div>
        </>
      </CheckPermission>

      {/* add modal */}
      <Modal show={show} onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_BANNER", language)}</Modal.Title>
          <Button variant="danger" onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Create
            loadSettingData={findListBanner}
            handleModalClose={handleModalClose}
            filterItem={filterItem}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal show={editModalShow} onHide={handleEditModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_BANNER", language)}</Modal.Title>
          <Button variant="danger" onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <Edit
            editData={editData}
            filterItem={filterItem}
            handleModalClose={handleEditModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
      {/* img modal */}
      <Modal show={viewModalShow} onHide={handleViewModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("IMAGE_URL", language)}</Modal.Title>
          <Button variant="danger" onClick={handleViewModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <img src={editData} height="200" width="400" />
        </Modal.Body>
      </Modal>
      {/*  modal */}
    </Content>
  );
}

export default Banner;
