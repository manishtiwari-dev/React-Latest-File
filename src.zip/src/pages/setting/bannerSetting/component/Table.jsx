import React from "react";
import CheckPermission from "helper";
import FeatherIcon from "feather-icons-react";
import { Modal, Button } from "react-bootstrap";
import ModalImage from "react-modal-image-responsive";

import {
    BadgeShow,
    Col,
    IconButton,
    Anchor,
  } from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalAlert from "component/ModalAlert";
import { useState } from "react";
import { PreUpdate, PreRemove, PreView } from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import { PageSetting } from "config/WebsiteUrl";

function Table({
  showColumn,
  bannerList,
  deleteFun,
  pageName,
  sortBy,
  orderBy,
  filterItem,
  editFun,
  updateStatusFunction,
  UpdateSortOrder,
  mainKey,
}) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deleteFun,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  // change Status function
  const ChangeStatus = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: updateStatusFunction,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  // const editFunction = (editId) => {
  //   editFun(editId);
  // };
  // filter order by id,email etc...
  const searchItem = (value, ord) => {
    filterItem("sortby", value, ord);
  };

  const [showType, SetShowType] = useState("");
  const [showticketModal, SetshowticketModal] = useState(false);
  const handleshowticketModal = () => {
    SetshowticketModal(showticketModal ? false : true);
  };
  const [dashboardcontent, Setdashboardcontent] = useState("");
  const [viewid, setviewid] = useState("");
//   const editFunction = (updateId) => {
//     setviewid(updateId);
//     // setEditModalShow(true);
//     handleshowticketModal();
//   };
  const editFunction = (editId) => {
    editFun(editId);
  };

  return (
    <>
      <Col col={12}>
        <div className="table-responsive table-page">
          <table className="table">
            <thead>
              <tr>
                <th>{Trans("SL_NO", language)}</th>
                <th>{Trans("BANNER_NAME", language)}</th>
                <th>{Trans("BANNER", language)}</th>
                <th>{Trans("TEMPLATE_CODE", language)}</th>
                <th>{Trans("SORT_ORDER", language)}</th>
                <th>{Trans("STATUS", language)}</th>
                <th className="text-center">
                    {Trans("ACTION", language)}
                </th>
              </tr>
            </thead>
            <tbody>
                              {bannerList &&
                                bannerList.map((banner, idx) => {
                                  return (
                                    <tr key={idx}>
                                      <td>{idx + 1}</td>
                                      <td>{banner.banners_title}</td>
                                      <td>
                                        <ModalImage
                                          small={banner.image}
                                          large={banner.image}
                                        
                                          height="10"
                                          width="10"
                                          className="img50"
                                        />
                                      </td>
                                      <td>{ `[BANNERS ID=${banner?.banners_id} THEME=01]`}</td>
                                      <td >   
                                          <input
                                              type="number"
                                              name=""
                                              id=""
                                              defaultValue={banner.sort_order}

                                              style={{ width: "50px" , 'text-align':"center"}}                               
                                              onBlur={(e) => {
                                                UpdateSortOrder(
                                                  banner.banners_id,
                                                e.target.value
                                              );
                                          }}
                                          />
                                    </td>

                                      <td>
                                        <BadgeShow
                                          type={
                                            banner.status
                                              ? "active"
                                              : "deactive"
                                          }
                                          content={
                                            banner.status
                                              ? "active"
                                              : "deactive"
                                          }
                                        />{" "}
                                      </td>
                                      <td className="text-center">
                                        <a
                                          variant="primary"
                                          href={banner?.banners_url}
                                          target="_blank"
                                        >
                                          <FeatherIcon
                                            icon="external-link"
                                            size="18"
                                          />
                                        </a>{" "}
                                          
                    <CheckPermission PageAccess={pageName} PageAction={PreUpdate}>
                        <IconButton
                              color="primary"
                              onClick={() =>
                                editFunction(banner?.banners_id)
                              }
                            >
                              <FeatherIcon
                                icon="edit-2"
                                                               
                                fill="white"
                                onClick={() =>
                                  editFunction(banner?.banners_id)
                                }
                              />
                            </IconButton>{" "}
                            {"  "}
                            </CheckPermission>
                                       

                            <IconButton
                               color="primary"
                               onClick={() =>
                                ChangeStatus(banner?.banners_id)
                              }
                            >
                              <FeatherIcon
                                icon="repeat"
                                fill="white"
                                onClick={() =>
                                    ChangeStatus(banner?.banners_id)
                                }
                              />
                            </IconButton>
                            {"  "}
                            <IconButton
                               color="primary"
                               onClick={() =>
                                deleteItem(banner?.banners_id)
                              }
                            >
                              <FeatherIcon
                                 icon="x-square"
                                 color="white"
                                onClick={() =>
                                    deleteItem(banner?.banners_id)
                                }
                              />
                            </IconButton>
                            {"  "}
                                      </td>
                                    </tr>
                                  );
                                })}

                              {bannerList.length === 0 ? (
                                <tr>
                                  <td colSpan={6} className="text-center">
                                    {Trans(
                                      "NOT_FOUND_CHOOSE_BANNER_GROUP",
                                      language
                                    )}
                                  </td>
                                </tr>
                              ) : null}
                            </tbody>
          </table>
        </div>
      </Col>
    
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </>
  );
}

export default Table;
