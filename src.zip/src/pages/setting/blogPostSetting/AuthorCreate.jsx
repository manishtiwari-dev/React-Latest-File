import React, { useState, useEffect } from "react";
import POST from "axios/post";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import { useForm, FormProvider } from "react-hook-form";
import {
    PostAuthorStoreUrl,
    tempUploadFileUrl
  
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  Label,
  Anchor,
  StatusSelect,
  TextArea,
  GalleryImagePreviewWithUpload,
} from "component/UIElement/UIElement";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { ErrorMessage } from "@hookform/error-message";
import Select from "react-select";
import WebsiteLink from "config/WebsiteLink";

import FeatherIcon from "feather-icons-react";
import { useNavigate } from "react-router-dom";

const TagCreate = (props) => {
  const navigate = useNavigate();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);

  const methods = useForm({
    
  });

  const {
    register,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors },
  } = methods;
  const [field, SetFeature] = useState([]);

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    const saveFormData = formData;
    saveFormData.api_token = apiToken;
     saveFormData.api_token = apiToken;
  
    // return "";

    POST(PostAuthorStoreUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, data, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
          Notify(true, errObj.msg);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };


  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        setValue(StoreID, response.data.data);
      })
      .catch((error) => {
        Notify(false, error.message);
      });
  };

 
  
  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
       <FormProvider {...methods}>
                  <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
                    <Row>
                    <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("AUTHOR_NAME", language)}
                label={Trans("AUTHOR_NAME", language)}
                placeholder={Trans("AUTHOR_NAME", language)}
                className="form-control form-control-sm"
                {...register("author_name", {
                  required: Trans("AUTHOR_NAME_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="author_name" />
              </span>
            </FormGroup>
                    </Col>

                       <Col col={6} className="mb-10">
                            <label>
                             <b>
                           {Trans("AUTHOR_IMAGES")} 
                            </b>
                          </label>
                          <input type="hidden"
                            {...register("author_image", 
                             
                            )}  />
                          <input
                            placeholder="Setting Value"
                            className="form-control"
                            type="file"
                            onChange={(event) =>
                              HandleDocumentUpload(event, `fileupload`, `author_image`)
                            }
                          />
                         
                          <div id={`fileupload`}></div>
                          </Col> <br /> 




                    <Col col={6}>
                      <FormGroup>
                    <Input
                      id={Trans("AUTHOR_DESIGNATION", language)}
                      label={Trans("AUTHOR_DESIGNATION", language)}
                      placeholder={Trans("AUTHOR_DESIGNATION", language)}
                      className="form-control form-control-sm"
                      {...register("author_designation", {
                        required: Trans("AUTHOR_DESIGNATION_REQUIRED", language),
                      })}
                    />
                  <span className="required">
                    <ErrorMessage errors={errors} name="author_designation" />
                  </span>
               </FormGroup>
                    </Col>
           

                     
                          <Col col={6}>
                            <FormGroup mb="20px">
                            <TextArea
                              id={Trans("AUTHOR_DETAILS", language)}
                              label={Trans("AUTHOR_DETAILS", language)}
                              placeholder={Trans("AUTHOR_DETAILS", language)}
                              className="form-control"
                              {...register(`author_details`)}
                            />
                          <span className="required">
                            <ErrorMessage
                              errors={errors}
                              name={`author_details`}
                            />
                          </span>
                    </FormGroup>
                          </Col>
         
          
                      <Col col={4} className="mt-2">
                        <LoaderButton
                          formLoadStatus={formloadingStatus}
                          btnName={Trans("SUBMIT", language)}
                          className="btn btn-primary btn-block"
                        />
                      </Col>
                      <br />
                    </Row>
                  </form>
                </FormProvider>
    </>
  );
};

export default TagCreate;
