import React from "react";
import CheckPermission from "helper";
import FeatherIcon from "feather-icons-react";
import {
  BadgeShow,
  Col,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalAlert from "component/ModalAlert";
import { useState } from "react";
import { PreUpdate, PreRemove, PreView } from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import { BlogPostSetting } from "config/WebsiteUrl";
import ModalImage from "react-modal-image-responsive";
import { Modal, Button } from "react-bootstrap";
import ViewModal from "./ViewModal";
function Table({
  showColumn,
  dataList,
  deleteFun,
  pageName,
  sortBy,
  orderBy,
  filterItem,
  curPage,
  perPage,
  editFun,
  updateStatusFunction,
  updateIsfeatureFunction,
  mainKey,
}) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };
  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deleteFun,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  // change Status function
  const ChangeStatus = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: updateStatusFunction,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  // filter order by id,email etc...
  const searchItem = (value, ord) => {
    filterItem("sortby", value, ord);
  };

  const [showType, SetShowType] = useState("");
  const [showticketModal, SetshowticketModal] = useState(false);
  const handleshowticketModal = () => {
    SetshowticketModal(showticketModal ? false : true);
  };
  const [dashboardcontent, Setdashboardcontent] = useState("");
  const [viewid, setviewid] = useState("");
 

  const editFunction = (editId) => {
    editFun(editId);
  };

  const StatusChange = (quoteId, statusId) => {
    updateIsfeatureFunction(quoteId, statusId);
  };

  const statusColor = ["danger",  "success", ];



  let rowId = (curPage>1)? (curPage-1)* perPage : 0;


  return (
    <>
      <Col col={12}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>{Trans("SL_NO", language)}</th>
                <th>{Trans("TAG_NAME", language)}</th>
                <th>{Trans("STATUS", language)}</th>
                <th>{Trans("ACTION", language)}</th>
              </tr>
            </thead>
            <tbody>
              {dataList.length > 0 &&
                dataList.map((cat, IDX) => {
                  const { tags_id, tags_name, status, } =
                    cat;
                    rowId++;
                  return (
                    <React.Fragment key={IDX}>
                      <tr>
                        <td>{rowId}</td>

                        <td>{tags_name}</td>
                       
                        <td>
                        <div
                          className="custom-control custom-switch "

                           >
                        <input
                                onClick={() => {
                                  updateStatusFunction(
                                    tags_id
                                  );
                                }}
                                type="checkbox"
                                class="custom-control-input"
                                id={`customSwitch${tags_id}`}
                                checked={
                                  status === 0
                                    ? ""
                                    : "checked"
                                }
                         />
                            <label
                              className="custom-control-label"
                              For={`customSwitch${tags_id}`}
                            ></label>
                          </div>
                       
                        </td>

                      

                        <td>

                        <CheckPermission
                            PageAccess={pageName}
                            PageAction={PreUpdate}
                          >
                            <IconButton
                              color="primary"
                              onClick={() => editFunction(tags_id)}
                            >
                              <FeatherIcon
                                icon="edit-2"
                                fill="white"
                                size={20}
                                onClick={() => editFunction(tags_id)}
                              />
                            </IconButton>{" "}
                          </CheckPermission>
                       
                         
                        

                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Col>
      <Modal show={showticketModal} onHide={handleshowticketModal} size="xl">
        <Modal.Header>
          <Modal.Title>{Trans("VIEW_PAGE", language)}</Modal.Title>
          <Button variant="danger" onClick={handleshowticketModal}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <ViewModal editid={viewid} />
        </Modal.Body>
      </Modal>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </>
  );
}

export default Table;
