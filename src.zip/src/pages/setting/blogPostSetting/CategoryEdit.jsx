import React, { useState } from "react";
import POST from "axios/post";
import { useForm, FormProvider } from "react-hook-form";
import { useParams } from "react-router-dom";
import {
    PostCategoryUpdateUrl,
  tempUploadFileUrl,
  PostCategoryEditUrl,
} from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import Select from "react-select";
import { useNavigate } from "react-router-dom";

import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  Input,
  StatusSelect ,
  Anchor,
  Label,
  GalleryImagePreviewWithUploadWithItem,
} from "component/UIElement/UIElement"
import Loading from "component/Preloader";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import { useEffect } from "react";
import { ErrorMessage } from "@hookform/error-message";
// import Loading from "component/Loading";


const Edit = (props) => {
  const { proId } = useParams();
  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const navigate = useNavigate();

  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const { editData } = props;

  const [editProAttribute, SetEditProAttribute] = useState();
  const [editLoad, SeteditLoad] = useState(false);

  const methods = useForm();

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    getValues,
  } = methods;

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
  

    const saveFormData = formData;
    saveFormData.api_token = apiToken;
  

    POST(PostCategoryUpdateUrl, saveFormData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message, data } = response.data;
        if (status) {
          setError({
            status: true,
            msg: message,
            type: "success",
          });
          props.filterItem("refresh", "", "");
          props.handleModalClose();
          Notify(true, Trans(message, language));
        
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = message;
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        Notify(false, error.message);
      });
  };
  
  const [sectionListing, SetSectionListing] = useState([]);

  const [editInfo, SeteditInfo] = useState("");
  useEffect(() => {
    let abortController = new AbortController();
    function setValueToField() {
      const editInfo = {
        api_token: apiToken,
        category_id: editData,
      };
      POST(PostCategoryEditUrl, editInfo)
        .then((response) => {
          SetloadingStatus(false);
          const { data } = response.data;
          
          SeteditInfo(data.data_list);
          SetSectionListing(data.parent_type);

          const fieldList = getValues();
          for (const key in fieldList) {
        
            setValue(key, data.data_list[key]);
          }
          SeteditLoad(true);
        })
        
        .catch((error) => {
            SetloadingStatus(false);
          alert(error.message);
        });
    }
    setValueToField();
    return () => {
      // setValueToField();
      abortController.abort();
    };
  }, []);


  const [tempFile, SettempFile] = useState("");


  const HandleDocumentUpload = (event, previewUrlId, StoreID) => {
    if (event.target.files[0] === "" || event.target.files[0] === undefined)
      return;

    var readers = new FileReader();
    readers.onload = function (e) {
      document.getElementById(
        previewUrlId
      ).innerHTML = `<img src=${e.target.result} height="100" />`;
    };
    readers.readAsDataURL(event.target.files[0]);

    // upload temp image and bind value to array
    const formdata = new FormData();
    formdata.append("api_token", apiToken);
    formdata.append("fileInfo", event.target.files[0]);
    formdata.append("images_type", 1);
    POST(tempUploadFileUrl, formdata)
      .then((response) => {
        setValue(StoreID, response.data.data);
        SettempFile( response.data.data);

      })
      .catch((error) => {
        Notify(false, error.message);
      });
  };

  console.log(editInfo);
  return (
    <>
      {contentloadingStatus ? (
        <Loading />
      ) : (
        <>
          {error.status && (
            <Alert
              variant={error.type}
              onClose={() => setError({ status: false, msg: "", type: "" })}
              dismissible
            >
              {error.msg}
            </Alert>
          )}
                        <FormProvider {...methods}>
                  <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
                    <input type="hidden" {...register("category_id")} />
                    <Row>

                    <Col col={6}>
            <FormGroup>
              <Input
                id={Trans("CATEGORY_NAME", language)}
                label={Trans("CATEGORY_NAME", language)}
                placeholder={Trans("CATEGORY_NAME", language)}
                className="form-control form-control-sm"
                {...register("category_name", {
                  required: Trans("CATEGORY_NAME_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="category_name" />
              </span>
            </FormGroup>
                    </Col>


      
          <Col col={6}>
          <FormGroup mb="20px">
          <Label
                  display="block"
                  mb="5px"
                  htmlFor={Trans("PARENT_NAME", language)}
                >
                  {Trans("PARENT_NAME", language)}
                </Label>
              <select
                id="Status"
                label={Trans("STATUS", language)}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register("parent_id", {
                  required: Trans("PARENT_NAME_REQUIRED", language),
                })}
              >
               <option value={0}>---</option>
        
               {sectionListing &&
                    sectionListing?.map((curr, idx) => (
                      <option value={curr.category_id} key={idx}>
                        {curr.category_name}
                      </option>
                     ))}


            

        </select>
        <span className="required">
                <ErrorMessage errors={errors} name="form_type" />
              </span>
            </FormGroup>
          </Col>

          <Col col={6} className="mb-10">
                            <label>
                             <b>
                           {Trans("IMAGES")} 
                            </b>
                          </label>
                          <input type="hidden"
                            {...register("image_id", {
                            })}  
                            
                            />
                          <input
                            placeholder="Setting Value"
                            className="form-control"
                            type="file"
                            onChange={(event) =>
                              HandleDocumentUpload(event, `fileupload`, `image_id`)
                            }
                          />
                         
                          <div id={`fileupload`}>
                          <img src={editInfo?.banner_cat_image} height="100" />

                          </div>
                         
                          </Col> <br /> 

      
          <Col col={6}>
            <FormGroup mb="20px">
              <StatusSelect
                id="Status"
                label={Trans("STATUS", language)}
                defaultValue={1}
                hint="Enter text" // for bottom hint
                className="form-control form-control-sm"
                {...register("status", {
                  required: Trans("STATUS_REQUIRED", language),
                })}
              />
            
            </FormGroup>
          </Col>

          {tempFile === null?
                 <Loading />
                         :
                 <>
                <Col col={4} className="mt-2">
                        <LoaderButton
                          formLoadStatus={formloadingStatus}
                          btnName={Trans("UPDATE", language)}
                          className="btn btn-primary btn-block"
                        />
                      </Col>
                </>
          }
      
            
                      <br />
                    </Row>
                  </form>
                  </FormProvider>
        </>
      )}
    </>
  );
};

export default Edit;
