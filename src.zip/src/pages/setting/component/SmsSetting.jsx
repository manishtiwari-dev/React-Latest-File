import React from "react";

function SmsSetting() {
  return <></>;
}

export default SmsSetting;
