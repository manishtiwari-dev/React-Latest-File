import React, { useEffect, useState } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { SliderUpdateUrl, SliderEditUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  StatusSelect,
  Col,
  Input,
} from "component/UIElement/UIElement";
import { ErrorMessage } from "@hookform/error-message";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";

const EditSlider = (props) => {
  const { editData } = props;

  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const {
    register,
    formState: { errors },
    setValue,
    getValues,
    handleSubmit,
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    formData.api_token = apiToken;
    POST(SliderUpdateUrl, formData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
          props.handleModalClose();
          props.loadSettingData();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              console.log(message[key][0]);
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = Trans(message, language);
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  function setValueToField() {
    const editInfo = {
      api_token: apiToken,
      sliders_id: editData,
    };

    POST(SliderEditUrl, editInfo)
      .then((response) => {
        SetloadingStatus(false);
        const { data } = response.data;
        const fieldList = getValues();
        for (const key in fieldList) {
          console.log(key, data[key]);
          setValue(key, data[key]);
        }
      })
      .catch((error) => {
        SetloadingStatus(false);
        Notify(false, error.message);
      });
  }
  // update
  useEffect(() => {
    let abortController = new AbortController();
    setValueToField();
    return () => abortController.abort();
  }, []);

  return (
    <>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <input type="hidden" {...register("sliders_id")} />
        <Row>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
                id={Trans("SLIDER_TITLE", language)}
                label={Trans("SLIDER_TITLE", language)}
                placeholder={Trans("SLIDER_TITLE", language)}
                className="form-control"
                {...register("sliders_title", {
                  required: Trans("SLIDER_TITLE_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="sliders_title" />
              </span>
            </FormGroup>
          </Col>
          <Col col={6}>
            <FormGroup mb="20px">
              <Input
               type="number"
                id={Trans("CAROUSEL_ITEM", language)}
                label={Trans("CAROUSEL_ITEM", language)}
                placeholder={Trans("CAROUSEL_ITEM", language)}
                className="form-control"
                {...register("carousel_item", {
                 
                })}
              />
            
            </FormGroup>
          </Col>

          {/* <Col col={6}>
            <FormGroup mb="20px">
              <Input
               type="number"
                id={Trans("CAROUSEL_WIDTH", language)}
                label={Trans("CAROUSEL_WIDTH", language)}
                placeholder={Trans("CAROUSEL_WIDTH", language)}
                className="form-control"
                {...register("carousel_width", {
                  required: Trans("CAROUSEL_WIDTH_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="carousel_width" />
              </span>
            </FormGroup>
          </Col> */}
          <Col col={12}>
            <FormGroup mb="20px">
              <StatusSelect
                id="Status"
                label={Trans("STATUS", language)}
                hint="Enter text" // for bottom hint
                className="form-control"
                {...register("status", )}
              
              />
            
            </FormGroup>
          </Col>

          <Col col={4}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("UPDATE", language)}
              className="btn btn-primary btn-block"
            />
          </Col>
        </Row>
      </form>
    </>
  );
};

export default EditSlider;
