import React, { useState } from "react";
import { Trans } from "lang";
import { useSelector } from "react-redux";
import {
  FormGroup,
  Row,
  Col,
  Label,
  Input,
  TextArea,
} from "component/UIElement/UIElement";
import { Tab, Tabs } from "react-bootstrap";
import { useFormContext } from "react-hook-form";
import { ErrorMessage } from "@hookform/error-message";
import MyEditor from "component/MyEditor";
import ContentEditor from "component/ContentEditor";

function LangPageInfo({ langList }) {
  const { language } = useSelector((state) => state.login);
  const [key, setKey] = useState("default_language");
  const methods = useFormContext();
  const {
    register,
    setValue,
    getValues,
    formState: { errors },
  } = methods;

  const myfun =()=>  {
 
    var a = document.getElementById(`slug-source_${language}`).value;
  
      var b = a.toLowerCase().replace(/ /g, '-')
      .replace(/[^\w-]+/g, '');

      document.getElementById(`slug-target_${language}`).value = b;

    
};

  
  return (
    <Col col={12}>
      <Tabs
        id="controlled-tab-example"
       
        onSelect={(k) => setKey(k)}
        className="mb-3"
      >
        {langList &&
          langList.map((lang) => {
            const { languages_code, languages_id, languages_name } = lang;
            return (
              <Tab
                eventKey={languages_code}
                key={languages_id}
                title={languages_name}
              >
                <Row>
                                    <Col col={6}>
                                      <FormGroup mb="20px">
                                        <Input
                                            id={`slug-source_${languages_code}`}
                                          
                                          label={`${Trans(
                                            "PAGE_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          placeholder={`${Trans(
                                            "PAGE_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(
                                            `pages_title_${languages_id}`,
                                          
                                          )}

                                          onKeyUp={() => {
                                            myfun();
                                          }} 
                                        />
                                        {/* <span className="required">
                                          <ErrorMessage
                                            errors={errors}
                                            name={`pages_title_${languages_id}`}
                                          />
                                        </span> */}
                                      </FormGroup>
                                    </Col>

                                    <Col col={6}>
                                      <FormGroup mb="20px">
                                        <Input
                                          id={`slug-target_${languages_code}`}
                                          
                                        //  id={`slug-target`}
                                          label={`${Trans(
                                            "PAGE_SLUG",
                                            language
                                          )}`}
                                          placeholder={`${Trans(
                                            "PAGE_SLUG",
                                            language
                                          )} (${languages_code})`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(
                                            `pages_slug`,
                                            {
                                            
                                            }
                                          )}
                                        />
                                      
                                      </FormGroup>
                                    </Col>



                                    <Col col={12}>
                                      <FormGroup>
                                        <Label>
                                          {`${Trans(
                                            "PAGES_CONTENT",
                                            language
                                          )} (${languages_code})`}
                                        </Label>


                                        <ContentEditor
                                        className="Editor" 
                                        initialValue={ 
                                          
                                          getValues(
                                              `pages_content_${languages_id}`
                                            ) === undefined
                                              ? "<p></p>"
                                              : getValues(
                                                  `pages_content_${languages_id}`
                                                )
                                              
                                              }
                                        setKey={`pages_content_${languages_id}`}
                                        
                                        updateFun={(Key, Value) => {
                                          setValue(Key, Value);
                                        }}
                                        />
                                        
                                        <textarea
                                          {...register(
                                            `pages_content_${languages_id}`
                                          )}
                                          style={{ display: "none" }}
                                        ></textarea>


                                      </FormGroup>
                                    </Col>

                                    <Col col={12}>
                                      <FormGroup mb="20px">
                                        <Input
                                          id={`${Trans(
                                            "SEO_META_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          label={`${Trans(
                                            "SEO_META_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          placeholder={`${Trans(
                                            "SEO_META_TITLE",
                                            language
                                          )} (${languages_code})`}
                                          className="form-control"
                                          {...register(
                                            `seometa_title_${languages_id}`
                                          )}
                                       //   value={metaEditorValue}
                                        />
                                      </FormGroup>
                                    </Col>
                                    

                                     <Col col={12}>
                                      <FormGroup mb="20px">
                                        <TextArea
                                          // id={`${Trans(
                                          //   "SEO_META_DESCRIPTION",
                                          //   language
                                          // )} (${languages_code})`}
                                          label={`${Trans(
                                            "SEO_META_DESCRIPTION",
                                            language
                                          )} (${languages_code})`}
                                          placeholder={`${Trans(
                                            "SEO_META_DESCRIPTION",
                                            language
                                          )} (${languages_code})`}
                                          hint="Enter text" // for bottom hint
                                          className="form-control"
                                          {...register(
                                            `seometa_desc_${languages_id}`
                                          )}
                                         
                                      //    value={metaDescEditorValue}
                                        />

                                      </FormGroup>
                                    </Col> 
                                  </Row>
              </Tab>
            );
          })}
      </Tabs>
    </Col>
  );
}

export default LangPageInfo;
