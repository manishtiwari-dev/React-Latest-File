import React, { useState, useEffect } from "react";
import POST from "axios/post";
import { useForm } from "react-hook-form";
import { EmailTemplateUpdateUrl, EmailTemplateEditUrl } from "config/index";
import { useSelector } from "react-redux";
import { Trans } from "lang";
import {
  LoaderButton,
  FormGroup,
  Row,
  Col,
  TextArea,
  Label,
  Input,
} from "component/UIElement/UIElement";
import { ErrorMessage } from "@hookform/error-message";
import { Alert } from "react-bootstrap";
import Notify from "component/Notify";
import MyEditor from "component/MyEditor";
import ContentEditor from "component/ContentEditor";

const Edit = (props) => {
  const { editData } = props;

  const [value, setsValue] = useState("");
  const getValue = (value) => {
    setsValue(value);
  };


  const { apiToken, language } = useSelector((state) => state.login);
  const [error, setError] = useState({
    status: false,
    msg: "",
    type: "",
  });
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [key, setKey] = useState("en");
  const {
    register,
    formState: { errors },
    setValue,
    getValues,
    handleSubmit,
  } = useForm();

  const onSubmit = (formData) => {
    SetformloadingStatus(true);
    formData.api_token = apiToken;
    POST(EmailTemplateUpdateUrl, formData)
      .then((response) => {
        SetformloadingStatus(false);
        const { status, message } = response.data;
        if (status) {
          setError({
            status: true,
            msg: Trans(message, language),
            type: "success",
          });
          props.handleModalClose();
          props.filterItem();
          Notify(true, Trans(message, language));
        } else {
          var errObj = {
            status: true,
            msg: "",
            type: "danger",
          };

          if (typeof message === "object") {
            let errMsg = "";
            Object.keys(message).map((key) => {
              console.log(message[key][0]);
              errMsg += Trans(message[key][0], language);
              return errMsg;
            });
            errObj.msg = errMsg;
          } else {
            errObj.msg = Trans(message, language);
          }
          setError(errObj);
        }
      })
      .catch((error) => {
        SetformloadingStatus(false);
        setError({
          status: true,
          msg: error.message,
          type: "danger",
        });
      });
  };

  const [contentloadingStatus, SetloadingStatus] = useState(true);

  const [editorData, SeteditorData] = useState("");

  const setValueToField = () => {
    const editInfo = {
      api_token: apiToken,
      template_id: editData,
    };

    POST(EmailTemplateEditUrl, editInfo)
      .then((response) => {
        SetloadingStatus(false);
        const { data } = response.data;
        const fieldList = getValues();
        for (const key in fieldList) {
          setValue(key, data[key]);
        }

        SeteditorData(data["template_content"]);
      })
      .catch((error) => {
        SetloadingStatus(false);
        Notify(false, error.message);
      });
  };


  const [edit, setedit] = useState("");
  const [titleedit,setTitleedit] =useState("");
  const [Descedit,setDescedit] =useState("");



//  useEffect(() => {
   

//    function setter() {
//      setedit(tempEditorValue.pages_content);
//      setTitleedit(metaEditorValue.seometa_title);
//      setstitlevalue(metaEditorValue.seometa_title);

//      setDescedit(metaDescEditorValue.seometa_desc);
//      setsvalueDesc(metaDescEditorValue.seometa_desc);
     
//      setsValue(tempEditorValue.pages_content);

//    }
//    setter();
//    console.log("Current edit" + edit);
//  }, []);

//  const Changecontent = (e) => {
//    e.preventDefault();
//    setedit(value);
//    setsValue("");
//    setTitleedit(value);
//    setstitlevalue("");
//    setsvalueDesc("");
//    setDescedit(valueDesc);
//    console.log("Update EDit" + value);
//  };

  useEffect(() => {
    let abortController = new AbortController();
    setValueToField();
    return () => abortController.abort();
  }, []);

  return (
    <React.Fragment>
      {error.status && (
        <Alert
          variant={error.type}
          onClose={() => setError({ status: false, msg: "", type: "" })}
          dismissible
        >
          {error.msg}
        </Alert>
      )}
      <form action="#" onSubmit={handleSubmit(onSubmit)} noValidate>
        <input type="hidden" {...register("template_id")} />
        <input
          type="hidden"
          {...register("group_id")}
          defaultValue={props.groupId}
        />
        <Row>
          <Col col={12}>
            <FormGroup mb="20px">
              <Input
                id={Trans("template_subject", language)}
                label={Trans("template_subject", language)}
                placeholder={Trans("template_subject", language)}
                className="form-control"
                {...register("template_subject", {
                  required: Trans("TEMPLATE_SUBJECT_REQUIRED", language),
                })}
              />
              <span className="required">
                <ErrorMessage errors={errors} name="template_subject" />
              </span>
            </FormGroup>
          </Col>

          <Col col={12}>
              <FormGroup>
              <Label>{Trans("TEMPLATE_CONTENT", language)}</Label>

                <ContentEditor
                className="Editor" 
                initialValue= {editorData}
                setKey={`template_content`}
                updateFun={(Key, Value) => {
                  setValue(Key, Value);
                }}
                />
                
                <textarea
                  {...register(
                    `template_content`
                  )}
                  style={{ display: "none" }}
                ></textarea>
              <span className="required" style={{ marginTop: "10px" }}>
              <ErrorMessage errors={errors} name="template_content" />
            </span>
                                      </FormGroup>
                                    </Col>

{/* 
          <Col col={12}>
            <FormGroup>
              <Label>{Trans("TEMPLATE_CONTENT", language)}</Label>
              <MyEditor
                setKey={`template_content`}
                setVal={editorData}
                updateFun={(Key, Value) => {
                  setValue(Key, Value);
                }}
              />
              <textarea
                {...register(`template_content`, {
                  required: Trans("TEMPLATE_CONTENT_REQUIRED", language),
                })}
                style={{ display: "none" }}
              ></textarea>
              <span className="required" style={{ marginTop: "10px" }}>
                <ErrorMessage errors={errors} name="template_content" />
              </span>

              <span className="info">
                USER: ( [CUSTOMER_NAME], [CUSTOMER_EMAIL], [CUSTOMER_PHONE])
                <br />
                ORDER: ( [ORDER_NUMBER], [ORDER_SHIPPING], [ORDER_BILLING],
                [ORDER_ITEM] )
              </span>
            </FormGroup>
          </Col> */}
          <Col col={6}>
            <LoaderButton
              formLoadStatus={formloadingStatus}
              btnName={Trans("UPDATE", language)}
              className="btn btn-primary btn-block"
            />
          </Col>
        </Row>
      </form>
    </React.Fragment>
  );
};

export default Edit;
