import React, { useEffect, useState } from "react";
import Content from "layouts/content";
import PageHeader from "component/PageHeader";
import {
  BannerListUrl,
  BannerUpdateSettingUrl,
  MenuGroupUrl,
  MenuGroupChangeStatusUrl,
} from "config";
import POST from "axios/post";
import { useSelector } from "react-redux";
import { Trans } from "lang/index";
import CheckPermission from "helper";
import Loading from "component/Preloader";
import { Modal } from "react-bootstrap";
import { Button } from "react-bootstrap";
import { MenuSetting } from "config/WebsiteUrl";
import AddMenuGroup from "./AddMenuGroup";
import { Col, BadgeShow, Anchor ,IconButton} from "component/UIElement/UIElement";
import { useForm } from "react-hook-form";

import Notify from "component/Notify";
import FeatherIcon from "feather-icons-react";

import {
  MenusSetting,
  PreAdd,
  PreView,
  PreExport,
} from "config/PermissionName";

import EditMenuGroup from "./EditMenuGroup";
import WebsiteLink from "config/WebsiteLink";

function MenuGroup() {
  const { apiToken, language, userType } = useSelector((state) => state.login);
  const [contentloadingStatus, SetloadingStatus] = useState(true);
  const [formloadingStatus, SetformloadingStatus] = useState(false);
  const [sortByS, SetsortByS] = useState("sort_order");
  const [orderByS, SetOrderByS] = useState("ASC");

  const [listData, SetlistData] = useState([]);
  const [HelperData, SetHelperData] = useState([]);

  const methods = useForm({
    defaultValues: {
      settingdata: [
        {
          banner_setting_id: 1,
          template_id: 1,
          refrence_id: "asdsad",
          banner_position_id: "",
          images_id: "",
          comment: 1,
        },
      ],
    },
  });

  const {
    register,
    control,
    formState: { errors },
    getValue,
    handleSubmit,
  } = methods;

  const loadSettingData = ( sortBys, OrderBy) => {
    const filterData = {
      api_token: apiToken,
      sortBy: sortBys,
      orderBY: OrderBy,
    };
    POST(MenuGroupUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        if (status) {
          SetloadingStatus(false);
          SetSectionListing(data.data_list);
        } else Notify(true, Trans(message, language));
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  useEffect(() => {
    document.title = "Menu Setting | WorkerMan";
    let abortController = new AbortController();
    loadSettingData();
    return () => abortController.abort();
  }, []);

  const [show, setShow] = useState(false);
  const handleModalClose = () => setShow(false);
  const handleModalShow = () => setShow(true);

  useEffect(() => {}, [listData]);

  // handle change group name
  const [sectionListing, SetSectionListing] = useState([]);

  const [bannerList, SetBannerList] = useState([]);

  const changeStatus = (id) => {
    const filterData = {
      api_token: apiToken,
      group_id: id,
    };
    POST(MenuGroupChangeStatusUrl, filterData)
      .then((response) => {
        const { status, data, message } = response.data;
        Notify(true, Trans(message, language));
        loadSettingData();
      })
      .catch((error) => {
        Notify(true, Trans(error.message, language));
      });
  };

  const [editModalShow, setEditModalShow] = useState(false);
  const handleEditModalClose = () => setEditModalShow(false);
  const [editData, SetEditData] = useState();

  const editFunction = (updateId) => {
    SetEditData(updateId);
    setEditModalShow(true);
  };

  return (
    <Content>
      <CheckPermission PageAccess={MenusSetting} PageAction={PreView}>
        <>
         

          <div className="row row-xs">
            <div className="col-sm-12 col-lg-12">
              <CheckPermission PageAccess={MenusSetting} PageAction={PreView}>
                <div className="card" id="custom-user-list">
                  {/* CARD HEADER */}

                  <div className="card-header pd-y-15 pd-x-20 d-flex align-items-center justify-content-between">
                    <h6 className=" tx-semibold mg-b-0">
                      {Trans("MENU_GROUP_LIST", language)}
                    </h6>
                    <div className="d-none d-md-flex">
                    <CheckPermission
                    PageAccess={MenusSetting}
                    PageAction={PreAdd}
                  >
                 
                        <Button variant="primary" onClick={handleModalShow}>
                        <FeatherIcon
                          icon="plus"
                          fill="white"
                          className="wd-10 mg-r-5"
                        />
                     {Trans("ADD_MENU_GROUP", language)}
                      </Button>
   
                       </CheckPermission>
                    </div>
                  </div>

                  {/* END CARD HEADER */}
                  {contentloadingStatus ? (
                    <Loading />
                  ) : (
                    <div className="card-body">
                      <Col col={12}>
                        <div className="table-responsive">
                          <table className="table">
                            <thead>
                              <tr>
                                <th>{Trans("SL_NO", language)}</th>
                                <th>{Trans("GROUP_NAME", language)}</th>
                                <th>{Trans("GROUP_POSITION", language)}</th>
                                <th>{Trans("STATUS", language)}</th>
                                <th className="text-center">
                                  {Trans("ACTION", language)}
                                </th>
                              </tr>
                            </thead>
                            <tbody>
                              {sectionListing &&
                                sectionListing.map((banner, idx) => {
                                  return (
                                    <tr key={idx}>
                                      <td>{idx + 1}</td>
                                      <td>{banner.group_name}</td>
                                      <td>{banner.group_position}</td>
                                      <td>
                                        <BadgeShow
                                          type={
                                            banner.status
                                              ? "active"
                                              : "deactive"
                                          }
                                          content={
                                            banner.status
                                              ? "active"
                                              : "deactive"
                                          }
                                        />{" "}
                                      </td>
                                      <td className="text-center">


                                      <IconButton
                                    color="primary"
                                    onClick={() =>
                                      editFunction(
                                        banner?.banners_group_id
                                      )
                                    }
                                    >
                                    <FeatherIcon
                                      icon="edit-2"
                                                                    
                                      fill="white"
                                      onClick={() =>
                                        editFunction(
                                          banner?.group_id
                                        )
                                      }
                                    />
                                    </IconButton>


                                      <Anchor     
                               color="primary"
                               path={WebsiteLink(
                                `${MenuSetting}/${banner?.group_id}`
                              )}
                               className="btn btn-primary btn-xs btn-icon"
                            >
                              <FeatherIcon  icon="eye"
                                              />
                            </Anchor>
                            {"  "}
                    

                                     
                                        {/* {userType !== "subscriber" && ( */}

                                    {/* <IconButton
                                    color="primary"
                                    onClick={() =>
                                      editFunction(
                                        banner?.banners_group_id
                                      )
                                    }
                                    >
                                    <FeatherIcon
                                      icon="edit-2"
                                                                    
                                      fill="white"
                                      onClick={() =>
                                        editFunction(
                                          banner?.group_id
                                        )
                                      }
                                    />
                                    </IconButton> */}


                                        {/* )} */}

                                        {"  "}
                              <IconButton
                                  color="primary"
                                  onClick={() =>
                                    changeStatus(banner?.group_id)
                                  }
                              >
                              <FeatherIcon
                                icon="repeat"
                                fill="white"
                                onClick={() =>
                                  changeStatus(banner?.group_id)
                                }
                              />
                            </IconButton>
                            {"  "}

                                      

                                       
                                      </td>
                                    </tr>
                                  );
                                })}

                              {sectionListing.length === 0 ? (
                                <tr>
                                  <td colSpan={6} className="text-center">
                                    {Trans(
                                      "NOT_FOUND_CHOOSE_BANNER_GROUP",
                                      language
                                    )}
                                  </td>
                                </tr>
                              ) : null}
                            </tbody>
                          </table>
                        </div>
                      </Col>
                    </div>
                  )}
                </div>
              </CheckPermission>
            </div>
          </div>
        </>
      </CheckPermission>

      {/* add modal */}
      <Modal show={show} onHide={handleModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("ADD_MENU_GROUP", language)}</Modal.Title>
          <Button variant="danger" onClick={handleModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <AddMenuGroup
            loadSettingData={loadSettingData}
            handleModalClose={handleModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}

      {/* edit modal */}
      <Modal show={editModalShow} onHide={handleEditModalClose}>
        <Modal.Header>
          <Modal.Title>{Trans("UPDATE_MENU_GROUP", language)}</Modal.Title>
          <Button variant="danger" onClick={handleEditModalClose}>
            X
          </Button>
        </Modal.Header>
        <Modal.Body>
          <EditMenuGroup
            editData={editData}
            loadSettingData={loadSettingData}
            handleModalClose={handleEditModalClose}
          />
        </Modal.Body>
      </Modal>
      {/* end end modal */}
    </Content>
  );
}

export default MenuGroup;
