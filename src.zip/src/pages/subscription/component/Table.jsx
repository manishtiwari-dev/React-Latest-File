import React from "react";
import CheckPermission from "helper";
import FeatherIcon from "feather-icons-react";
import {
  BadgeShow,
  Col,
  IconButton,
  Anchor,
} from "component/UIElement/UIElement";
import { Trans } from "lang/index";
import { useSelector } from "react-redux";
import ModalAlert from "component/ModalAlert";
import { useState } from "react";
import { PreUpdate, PreRemove, PreView } from "config/PermissionName";
import WebsiteLink from "config/WebsiteLink";
import { SettingGroup } from "config/WebsiteUrl";

function Table({
  dataList,
  deleteFun,
  pageName,
  filterItem,
  editFun,
  viewFunction,
  updateStatusFunction,
  approvalStatus,
}) {
  const { apiToken, language } = useSelector((state) => state.login);
  const [showModalAlert, SetshowModalAlert] = useState(false);

  const closeModal = () => {
    SetshowModalAlert(false);
  };

  const [ModalObject, SetModalObject] = useState({
    status: false,
    msg: "",
    functionName: "",
    param: "",
  });

  // delete function
  const deleteItem = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure !",
      functionName: deleteFun,
      param: deleteId,
      closeModal: closeModal,
    });
  };
  // change Status function
  const ChangeStatus = (deleteId) => {
    SetshowModalAlert(true);
    SetModalObject({
      msg: "Are you sure want to change status !",
      functionName: updateStatusFunction,
      param: deleteId,
      closeModal: closeModal,
    });
  };

  const editFunction = (editId) => {
    editFun(editId);
  };

  const viewFun = (editId) => {
    viewFunction(editId);
  };
  const StatusChange = (quoteId, statusId) => {
    updateStatusFunction(quoteId, statusId);
  };

  return (
    <>
      <Col col={12}>
        <div className="table-responsive">
          <table className="table">
            <thead>
              <tr>
                <th>{Trans("SL_NO", language)}</th>
                <th>{Trans("Subscription Id", language)}</th>
                <th>{Trans("Customer Name", language)}</th>
                <th>{Trans("Customer Email", language)}</th>
                {/* <th>{Trans("INDUSTRY_NAME", language)}</th>
                <th>{Trans("DB_PREFIX", language)}</th>
                <th>{Trans("WEBSITE", language)}</th> */}

                <th>{Trans("EXPIRE_DATE", language)}</th>
                <th>{Trans("STATUS", language)}</th>

                <th className="text-center">{Trans("ACTION", language)}</th>
              </tr>
            </thead>
            <tbody>
              {dataList.length > 0 &&
                dataList.map((cat, IDX) => {
                  const {
                    customer_id,
                    payment_date,
                    payment_status,
                    subscriber_plan_duration,
                    subscriber_plan_name,
                    subscriber_industry,
                    subscriber_first_name,
                    subscription_unique_id,
                    subscriber_approval_status,
                    domain_url,
                    approval_date,
                    status,
                    subscription_id,
                    db_suffix,
                    subscriber_email,
                    subs_txn_id,
                    expired_at,
                    categories_slug,
                  } = cat;
                  return (
                    <React.Fragment key={IDX}>
                      <tr>
                        <td>{IDX + 1}</td>

                        <td>
                          {" "}
                          <Anchor
                            path={WebsiteLink(
                              `/service-subscription/view/${subscription_id}`
                            )}
                            className="primary"
                          >
                            {subscription_unique_id}{" "}
                          </Anchor>
                        </td>
                        <td>{subscriber_first_name}</td>
                        <td>{subscriber_email}</td>
                        {/* <td>{subscriber_industry}</td>
                        <td>{db_suffix}</td> */}
                        {/* <td>{domain_url}</td> */}

                        {/* <td>
                          <select
                            className={`badge badge`}
                            value={status}
                            onChange={(e) => {
                              StatusChange(subscription_id, e.target.value);
                            }}
                          >
                            {approvalStatus &&
                              approvalStatus.map((curr) => (
                                <option
                                  value={curr.subscription_id}
                                  key={curr.subscription_id}
                                >
                                  {curr.subscriber_approval_status}
                                </option>
                              ))}
                          </select>
                        </td>
                       */}
                        <td>{expired_at}</td>

                        <td>
                          <BadgeShow
                            type={status === 1 ? "success" : "danger"}
                            content={status === 1 ? "Active" : "Deactive"}
                          />
                        </td>
                        <td className="text-center">
                          <CheckPermission
                            PageAccess={pageName}
                            PageAction={PreUpdate}
                          >
                            <IconButton
                              color="primary"
                              // onClick={() => editFunction(business_id)}
                            >
                              <Anchor
                                path={WebsiteLink(
                                  `/service-subscription/view/${subscription_id}`
                                )}
                              >
                                {
                                  <FeatherIcon
                                    icon="eye"
                                    fill="white"
                                    size={20}
                                    // onClick={() => editFunction(business_id)}
                                  />
                                }
                              </Anchor>
                            </IconButton>{" "}
                          </CheckPermission>
                        </td>
                      </tr>
                    </React.Fragment>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Col>
      {showModalAlert && <ModalAlert ModalObject={ModalObject} />}
    </>
  );
}

export default Table;
